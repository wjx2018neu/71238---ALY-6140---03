
- This notebook is for training the model for predicting the column "lights" while it is considered as categorical data, with "epochs = 100, batch_size = 512".


```python
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import random as rn
import tensorflow as tf

from keras import backend as K
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.models import load_model
from keras.layers import LSTM
from keras.models import Sequential
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
```

    Using TensorFlow backend.
    


```python
# prepare the functions for evaluating the model
def mse(ar1, ar2):
    return ((ar1 - ar2) ** 2).mean()

def rmse(ar1, ar2):
    return np.sqrt(mse(ar1, ar2))
```


```python
# make the results reproducible
os.environ["PYTHONHASHSEED"] = '0'
np.random.seed(1)
rn.seed(2)
tf.set_random_seed(3)
session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
```


```python
# loading and preprocessing data
energydata_complete = pd.read_csv("energydata_complete.csv").iloc[:, 1:]

energydata_complete = energydata_complete.drop(['Appliances'], axis=1)

Y = energydata_complete.iloc[:, 0].values

labelencoder_Y_1 = LabelEncoder()
Y_labled = labelencoder_Y_1.fit_transform(Y)

onehotencoder = OneHotEncoder(categorical_features = [0])
Y_onehot = onehotencoder.fit_transform(Y_labled.reshape(Y_labled.shape[0], 1)).toarray()
print(Y_onehot)

Y_columnnames = []
for i in range(Y_onehot.shape[1]):
    if i < 10:
        Y_columnnames.append("Y1_0{0}".format(i))
    else:
        Y_columnnames.append("Y1_{0}".format(i))

Y_onehot = pd.DataFrame(Y_onehot, columns = Y_columnnames)

sc = MinMaxScaler(feature_range = (0, 1))
variables_scaled = pd.DataFrame(sc.fit_transform(energydata_complete.iloc[:, 1:]), columns = list(energydata_complete.iloc[:, 1:].columns))
print(variables_scaled.head())
```

    [[0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     ...
     [0. 1. 0. ... 0. 0. 0.]
     [0. 1. 0. ... 0. 0. 0.]
     [0. 1. 0. ... 0. 0. 0.]]
            T1      RH_1        T2      RH_2        T3      RH_3        T4  \
    0  0.32735  0.566187  0.225345  0.684038  0.215188  0.746066  0.351351   
    1  0.32735  0.541326  0.225345  0.682140  0.215188  0.748871  0.351351   
    2  0.32735  0.530502  0.225345  0.679445  0.215188  0.755569  0.344745   
    3  0.32735  0.524080  0.225345  0.678414  0.215188  0.758685  0.341441   
    4  0.32735  0.531419  0.225345  0.676727  0.215188  0.758685  0.341441   
    
           RH_4        T5      RH_5    ...           T9      RH_9     T_out  \
    0  0.764262  0.175506  0.381691    ...     0.223032  0.677290  0.372990   
    1  0.782437  0.175506  0.381691    ...     0.226500  0.678532  0.369239   
    2  0.778062  0.175506  0.380037    ...     0.219563  0.676049  0.365488   
    3  0.770949  0.175506  0.380037    ...     0.219563  0.671909  0.361736   
    4  0.762697  0.178691  0.380037    ...     0.219563  0.671909  0.357985   
    
       Press_mm_hg    RH_out  Windspeed  Visibility  Tdewpoint       rv1       rv2  
    0     0.097674  0.894737   0.500000    0.953846   0.538462  0.265449  0.265449  
    1     0.100000  0.894737   0.476190    0.894872   0.533937  0.372083  0.372083  
    2     0.102326  0.894737   0.452381    0.835897   0.529412  0.572848  0.572848  
    3     0.104651  0.894737   0.428571    0.776923   0.524887  0.908261  0.908261  
    4     0.106977  0.894737   0.404762    0.717949   0.520362  0.201611  0.201611  
    
    [5 rows x 26 columns]
    

    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\_encoders.py:363: FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
    If you want the future behaviour and silence this warning, you can specify "categories='auto'".
    In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
      warnings.warn(msg, FutureWarning)
    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\_encoders.py:385: DeprecationWarning: The 'categorical_features' keyword is deprecated in version 0.20 and will be removed in 0.22. You can use the ColumnTransformer instead.
      "use the ColumnTransformer instead.", DeprecationWarning)
    


```python
# separate the data into training set and testing set
X_train_scaled = variables_scaled.iloc[:round(np.shape(variables_scaled)[0] * 0.8), :]
Y_train_encoded = Y_onehot.iloc[:round(np.shape(Y_onehot)[0] * 0.8), :]

X_test_scaled = variables_scaled.iloc[round(np.shape(variables_scaled)[0] * 0.8):, :]
Y_test_encoded = Y_onehot.iloc[round(np.shape(Y_onehot)[0] * 0.8):, :]

X_train_scaled = np.reshape(X_train_scaled.values, (X_train_scaled.values.shape[0], X_train_scaled.values.shape[1], 1))
X_test_scaled = np.reshape(X_test_scaled.values, (X_test_scaled.values.shape[0], X_test_scaled.values.shape[1], 1))
```


```python
# Initialising the RNN
layers = Sequential()

# Adding the first LSTM layer and some Dropout regularisation
layers.add(LSTM(units = 16, return_sequences = True, input_shape = (X_train_scaled.shape[1], 1)))
layers.add(Dropout(0.2))

layers.add(Flatten())

# Adding the output layer
layers.add(Dense(Y_train_encoded.shape[1], activation='softmax'))

layers.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
```


```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 135us/step - loss: 1.1885 - acc: 0.7109
    Epoch 2/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.8762 - acc: 0.7432
    Epoch 3/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.8649 - acc: 0.7432
    Epoch 4/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.8598 - acc: 0.7432
    Epoch 5/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.8562 - acc: 0.7432
    Epoch 6/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8528 - acc: 0.7432
    Epoch 7/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.8486 - acc: 0.7432
    Epoch 8/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.8472 - acc: 0.7432
    Epoch 9/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.8429 - acc: 0.7432
    Epoch 10/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8406 - acc: 0.7432
    Epoch 11/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.8360 - acc: 0.7432
    Epoch 12/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8360 - acc: 0.7432
    Epoch 13/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8315 - acc: 0.7432
    Epoch 14/100
    15788/15788 [==============================] - 1s 86us/step - loss: 0.8314 - acc: 0.7432
    Epoch 15/100
    15788/15788 [==============================] - 1s 87us/step - loss: 0.8287 - acc: 0.7432
    Epoch 16/100
    15788/15788 [==============================] - 1s 94us/step - loss: 0.8256 - acc: 0.7432
    Epoch 17/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8231 - acc: 0.7433
    Epoch 18/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8231 - acc: 0.7434
    Epoch 19/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8197 - acc: 0.7434
    Epoch 20/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8192 - acc: 0.7433
    Epoch 21/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8168 - acc: 0.7440
    Epoch 22/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8153 - acc: 0.7439
    Epoch 23/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8154 - acc: 0.7430
    Epoch 24/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8122 - acc: 0.7433
    Epoch 25/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8083 - acc: 0.7435
    Epoch 26/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8079 - acc: 0.7431
    Epoch 27/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.8056 - acc: 0.7431
    Epoch 28/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.8039 - acc: 0.7437
    Epoch 29/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7991 - acc: 0.7435
    Epoch 30/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7982 - acc: 0.7429
    Epoch 31/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7982 - acc: 0.7429
    Epoch 32/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7952 - acc: 0.7435
    Epoch 33/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7943 - acc: 0.7423
    Epoch 34/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7899 - acc: 0.7439
    Epoch 35/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7903 - acc: 0.7432
    Epoch 36/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7885 - acc: 0.7451
    Epoch 37/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7885 - acc: 0.7444
    Epoch 38/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7861 - acc: 0.7450
    Epoch 39/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7832 - acc: 0.7447
    Epoch 40/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7823 - acc: 0.7447
    Epoch 41/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7806 - acc: 0.7449
    Epoch 42/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7809 - acc: 0.7453
    Epoch 43/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7802 - acc: 0.7456
    Epoch 44/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7778 - acc: 0.7461
    Epoch 45/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7768 - acc: 0.7458
    Epoch 46/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7752 - acc: 0.7454
    Epoch 47/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7750 - acc: 0.7456
    Epoch 48/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7740 - acc: 0.7467
    Epoch 49/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7724 - acc: 0.7475
    Epoch 50/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7702 - acc: 0.7475
    Epoch 51/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7705 - acc: 0.7470
    Epoch 52/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7695 - acc: 0.7466
    Epoch 53/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7673 - acc: 0.7480
    Epoch 54/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7655 - acc: 0.7481
    Epoch 55/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7680 - acc: 0.7484
    Epoch 56/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7628 - acc: 0.7483
    Epoch 57/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7639 - acc: 0.7475
    Epoch 58/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7635 - acc: 0.7480
    Epoch 59/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7628 - acc: 0.7487
    Epoch 60/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7616 - acc: 0.7498
    Epoch 61/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7572 - acc: 0.7495
    Epoch 62/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7595 - acc: 0.7496
    Epoch 63/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7543 - acc: 0.7499
    Epoch 64/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7564 - acc: 0.7503
    Epoch 65/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7556 - acc: 0.7510
    Epoch 66/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7535 - acc: 0.7511
    Epoch 67/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7543 - acc: 0.7505
    Epoch 68/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7552 - acc: 0.7513
    Epoch 69/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7528 - acc: 0.7510
    Epoch 70/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7483 - acc: 0.7530
    Epoch 71/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7511 - acc: 0.7507
    Epoch 72/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7490 - acc: 0.7516
    Epoch 73/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7482 - acc: 0.7519
    Epoch 74/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7455 - acc: 0.7523
    Epoch 75/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7474 - acc: 0.7532
    Epoch 76/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7469 - acc: 0.7522
    Epoch 77/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7467 - acc: 0.7529
    Epoch 78/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7453 - acc: 0.7526
    Epoch 79/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7417 - acc: 0.7535
    Epoch 80/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7413 - acc: 0.7561
    Epoch 81/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7414 - acc: 0.7540
    Epoch 82/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7403 - acc: 0.7541
    Epoch 83/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7394 - acc: 0.7539
    Epoch 84/100
    15788/15788 [==============================] - 1s 78us/step - loss: 0.7365 - acc: 0.7565
    Epoch 85/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7376 - acc: 0.7554
    Epoch 86/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7383 - acc: 0.7547
    Epoch 87/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7349 - acc: 0.7556
    Epoch 88/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7363 - acc: 0.7560
    Epoch 89/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7341 - acc: 0.7560
    Epoch 90/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7318 - acc: 0.7546
    Epoch 91/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7328 - acc: 0.7556
    Epoch 92/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.7315 - acc: 0.7580
    Epoch 93/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7317 - acc: 0.7557
    Epoch 94/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7305 - acc: 0.7584
    Epoch 95/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7307 - acc: 0.7572
    Epoch 96/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7260 - acc: 0.7584
    Epoch 97/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7274 - acc: 0.7562
    Epoch 98/100
    15788/15788 [==============================] - 1s 86us/step - loss: 0.7286 - acc: 0.7570
    Epoch 99/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7258 - acc: 0.7586
    Epoch 100/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7255 - acc: 0.7572
    The accuracy(categorical) is: 0.8859893590068406
    The mean squared error is: 34.659234861920446
    


![png](output_7_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 106us/step - loss: 0.7239 - acc: 0.7589
    Epoch 2/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7247 - acc: 0.7594
    Epoch 3/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7257 - acc: 0.7579
    Epoch 4/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7223 - acc: 0.7610
    Epoch 5/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7240 - acc: 0.7585
    Epoch 6/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.7212 - acc: 0.7595
    Epoch 7/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7216 - acc: 0.7586
    Epoch 8/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.7200 - acc: 0.7610
    Epoch 9/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.7210 - acc: 0.7616
    Epoch 10/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7186 - acc: 0.7604
    Epoch 11/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7182 - acc: 0.7607
    Epoch 12/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7200 - acc: 0.7583
    Epoch 13/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7176 - acc: 0.7593
    Epoch 14/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7174 - acc: 0.7590
    Epoch 15/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7166 - acc: 0.7625
    Epoch 16/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7156 - acc: 0.7621
    Epoch 17/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7166 - acc: 0.7603
    Epoch 18/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7163 - acc: 0.7602
    Epoch 19/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7132 - acc: 0.7615
    Epoch 20/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7130 - acc: 0.7613
    Epoch 21/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7142 - acc: 0.7603
    Epoch 22/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7133 - acc: 0.7625
    Epoch 23/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7111 - acc: 0.7603
    Epoch 24/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7145 - acc: 0.7610
    Epoch 25/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7142 - acc: 0.7599
    Epoch 26/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7116 - acc: 0.7620
    Epoch 27/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7123 - acc: 0.7599
    Epoch 28/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7113 - acc: 0.7623
    Epoch 29/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7107 - acc: 0.7613
    Epoch 30/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7107 - acc: 0.7622
    Epoch 31/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7117 - acc: 0.7603
    Epoch 32/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7125 - acc: 0.7618
    Epoch 33/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7111 - acc: 0.7624
    Epoch 34/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7082 - acc: 0.7618
    Epoch 35/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7100 - acc: 0.7613
    Epoch 36/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7083 - acc: 0.7622
    Epoch 37/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7064 - acc: 0.7626
    Epoch 38/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7075 - acc: 0.7618
    Epoch 39/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7086 - acc: 0.7617
    Epoch 40/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7052 - acc: 0.7610
    Epoch 41/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7077 - acc: 0.7626
    Epoch 42/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7089 - acc: 0.7610
    Epoch 43/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7053 - acc: 0.7609
    Epoch 44/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7064 - acc: 0.7600
    Epoch 45/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7062 - acc: 0.7616
    Epoch 46/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7038 - acc: 0.7625
    Epoch 47/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.7052 - acc: 0.7616
    Epoch 48/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7056 - acc: 0.7624
    Epoch 49/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7036 - acc: 0.7624
    Epoch 50/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7036 - acc: 0.7620
    Epoch 51/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7045 - acc: 0.7626
    Epoch 52/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.7040 - acc: 0.7612
    Epoch 53/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7013 - acc: 0.7615
    Epoch 54/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7040 - acc: 0.7624
    Epoch 55/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7043 - acc: 0.7617
    Epoch 56/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7047 - acc: 0.7616
    Epoch 57/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7021 - acc: 0.7618
    Epoch 58/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7037 - acc: 0.7619
    Epoch 59/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7036 - acc: 0.7629
    Epoch 60/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7013 - acc: 0.7632
    Epoch 61/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7044 - acc: 0.7615
    Epoch 62/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7029 - acc: 0.7624
    Epoch 63/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7014 - acc: 0.7625
    Epoch 64/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7018 - acc: 0.7627
    Epoch 65/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7011 - acc: 0.7620
    Epoch 66/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7036 - acc: 0.7608
    Epoch 67/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6983 - acc: 0.7630
    Epoch 68/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7024 - acc: 0.7634
    Epoch 69/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7007 - acc: 0.7617
    Epoch 70/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6998 - acc: 0.7629
    Epoch 71/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6990 - acc: 0.7633
    Epoch 72/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.7002 - acc: 0.7622
    Epoch 73/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7012 - acc: 0.7616
    Epoch 74/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7004 - acc: 0.7618
    Epoch 75/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6970 - acc: 0.7643
    Epoch 76/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6998 - acc: 0.7623
    Epoch 77/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.7007 - acc: 0.7617
    Epoch 78/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6988 - acc: 0.7624
    Epoch 79/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6981 - acc: 0.7623
    Epoch 80/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6987 - acc: 0.7627
    Epoch 81/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6990 - acc: 0.7636
    Epoch 82/100
    15788/15788 [==============================] - 1s 86us/step - loss: 0.6982 - acc: 0.7623
    Epoch 83/100
    15788/15788 [==============================] - 1s 84us/step - loss: 0.6955 - acc: 0.7643
    Epoch 84/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6979 - acc: 0.7632
    Epoch 85/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6972 - acc: 0.7620
    Epoch 86/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6993 - acc: 0.7644
    Epoch 87/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6974 - acc: 0.7630
    Epoch 88/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6952 - acc: 0.7635
    Epoch 89/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6969 - acc: 0.7620
    Epoch 90/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6961 - acc: 0.7643
    Epoch 91/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6956 - acc: 0.7655
    Epoch 92/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6977 - acc: 0.7637
    Epoch 93/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6978 - acc: 0.7639
    Epoch 94/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6973 - acc: 0.7634
    Epoch 95/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6950 - acc: 0.7634
    Epoch 96/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6957 - acc: 0.7644
    Epoch 97/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6939 - acc: 0.7642
    Epoch 98/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6952 - acc: 0.7638
    Epoch 99/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6956 - acc: 0.7629
    Epoch 100/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6933 - acc: 0.7642
    The accuracy(categorical) is: 0.8844692171269318
    The mean squared error is: 35.67266278185964
    


![png](output_8_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 105us/step - loss: 0.6926 - acc: 0.7656
    Epoch 2/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6966 - acc: 0.7638
    Epoch 3/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6936 - acc: 0.7654
    Epoch 4/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6927 - acc: 0.7649
    Epoch 5/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6942 - acc: 0.7641
    Epoch 6/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6947 - acc: 0.7647
    Epoch 7/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6945 - acc: 0.7618
    Epoch 8/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6912 - acc: 0.7651
    Epoch 9/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6954 - acc: 0.7639
    Epoch 10/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6940 - acc: 0.7635
    Epoch 11/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6945 - acc: 0.7643
    Epoch 12/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6900 - acc: 0.7656
    Epoch 13/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6926 - acc: 0.7660
    Epoch 14/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6948 - acc: 0.7634
    Epoch 15/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6932 - acc: 0.7653
    Epoch 16/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6933 - acc: 0.7651
    Epoch 17/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6929 - acc: 0.7638
    Epoch 18/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6880 - acc: 0.7653
    Epoch 19/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6916 - acc: 0.7663
    Epoch 20/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6913 - acc: 0.7650
    Epoch 21/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6924 - acc: 0.7644
    Epoch 22/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6907 - acc: 0.7655
    Epoch 23/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6896 - acc: 0.7658
    Epoch 24/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6895 - acc: 0.7660
    Epoch 25/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6909 - acc: 0.7649
    Epoch 26/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6903 - acc: 0.7653
    Epoch 27/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6926 - acc: 0.7653
    Epoch 28/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6906 - acc: 0.7640
    Epoch 29/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6895 - acc: 0.7648
    Epoch 30/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6890 - acc: 0.7648
    Epoch 31/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6894 - acc: 0.7653
    Epoch 32/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6917 - acc: 0.7649
    Epoch 33/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6870 - acc: 0.7663
    Epoch 34/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6908 - acc: 0.7644
    Epoch 35/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6884 - acc: 0.7665
    Epoch 36/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6863 - acc: 0.7652
    Epoch 37/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6909 - acc: 0.7658
    Epoch 38/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6867 - acc: 0.7649
    Epoch 39/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6889 - acc: 0.7675
    Epoch 40/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6874 - acc: 0.7655
    Epoch 41/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6888 - acc: 0.7650
    Epoch 42/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6876 - acc: 0.7639
    Epoch 43/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6866 - acc: 0.7658
    Epoch 44/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6859 - acc: 0.7673
    Epoch 45/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6872 - acc: 0.7668
    Epoch 46/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6870 - acc: 0.7671
    Epoch 47/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6882 - acc: 0.7655
    Epoch 48/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6856 - acc: 0.7670
    Epoch 49/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6886 - acc: 0.7653
    Epoch 50/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6868 - acc: 0.7643
    Epoch 51/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6864 - acc: 0.7672
    Epoch 52/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6863 - acc: 0.7667
    Epoch 53/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6862 - acc: 0.7669
    Epoch 54/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6845 - acc: 0.7650
    Epoch 55/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6845 - acc: 0.7661
    Epoch 56/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6865 - acc: 0.7657
    Epoch 57/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6849 - acc: 0.7669
    Epoch 58/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6853 - acc: 0.7676
    Epoch 59/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6852 - acc: 0.7655
    Epoch 60/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6840 - acc: 0.7679
    Epoch 61/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6860 - acc: 0.7648
    Epoch 62/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6887 - acc: 0.7644
    Epoch 63/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6847 - acc: 0.7658
    Epoch 64/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6849 - acc: 0.7649
    Epoch 65/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6829 - acc: 0.7661
    Epoch 66/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6828 - acc: 0.7663
    Epoch 67/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6832 - acc: 0.7663
    Epoch 68/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6847 - acc: 0.7668
    Epoch 69/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6793 - acc: 0.7687
    Epoch 70/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6822 - acc: 0.7663
    Epoch 71/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6832 - acc: 0.7681
    Epoch 72/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6824 - acc: 0.7676
    Epoch 73/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6803 - acc: 0.7666
    Epoch 74/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6820 - acc: 0.7678
    Epoch 75/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6786 - acc: 0.7676
    Epoch 76/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6811 - acc: 0.7672
    Epoch 77/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6843 - acc: 0.7662
    Epoch 78/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6791 - acc: 0.7687
    Epoch 79/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6798 - acc: 0.7673
    Epoch 80/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6794 - acc: 0.7667
    Epoch 81/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6803 - acc: 0.7667
    Epoch 82/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6793 - acc: 0.7657
    Epoch 83/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6795 - acc: 0.7668
    Epoch 84/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6780 - acc: 0.7665
    Epoch 85/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6788 - acc: 0.7691
    Epoch 86/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6800 - acc: 0.7667
    Epoch 87/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6795 - acc: 0.7682
    Epoch 88/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6794 - acc: 0.7660
    Epoch 89/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6771 - acc: 0.7671
    Epoch 90/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6796 - acc: 0.7688
    Epoch 91/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6775 - acc: 0.7674
    Epoch 92/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6751 - acc: 0.7695
    Epoch 93/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6761 - acc: 0.7681
    Epoch 94/100
    15788/15788 [==============================] - 1s 78us/step - loss: 0.6762 - acc: 0.7670
    Epoch 95/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6765 - acc: 0.7684
    Epoch 96/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6762 - acc: 0.7693
    Epoch 97/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6741 - acc: 0.7677
    Epoch 98/100
    15788/15788 [==============================] - 2s 102us/step - loss: 0.6774 - acc: 0.7677
    Epoch 99/100
    15788/15788 [==============================] - 2s 108us/step - loss: 0.6738 - acc: 0.7680
    Epoch 100/100
    15788/15788 [==============================] - 2s 109us/step - loss: 0.6717 - acc: 0.7686
    The accuracy(categorical) is: 0.8806688624271599
    The mean squared error is: 37.192804661768434
    


![png](output_9_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6731 - acc: 0.7694
    Epoch 2/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6748 - acc: 0.7705
    Epoch 3/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6731 - acc: 0.7691
    Epoch 4/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6735 - acc: 0.7686
    Epoch 5/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6749 - acc: 0.7708
    Epoch 6/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6725 - acc: 0.7705
    Epoch 7/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6730 - acc: 0.7681
    Epoch 8/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.6762 - acc: 0.7691
    Epoch 9/100
    15788/15788 [==============================] - 2s 95us/step - loss: 0.6744 - acc: 0.7681
    Epoch 10/100
    15788/15788 [==============================] - 1s 94us/step - loss: 0.6745 - acc: 0.7691
    Epoch 11/100
    15788/15788 [==============================] - 2s 99us/step - loss: 0.6731 - acc: 0.7684
    Epoch 12/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.6711 - acc: 0.7680
    Epoch 13/100
    15788/15788 [==============================] - 2s 102us/step - loss: 0.6731 - acc: 0.7705
    Epoch 14/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.6703 - acc: 0.7701
    Epoch 15/100
    15788/15788 [==============================] - 2s 103us/step - loss: 0.6727 - acc: 0.7696
    Epoch 16/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.6710 - acc: 0.7674
    Epoch 17/100
    15788/15788 [==============================] - 2s 96us/step - loss: 0.6719 - acc: 0.7695
    Epoch 18/100
    15788/15788 [==============================] - 2s 101us/step - loss: 0.6705 - acc: 0.7699
    Epoch 19/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.6700 - acc: 0.7695
    Epoch 20/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6696 - acc: 0.7707
    Epoch 21/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6721 - acc: 0.7696
    Epoch 22/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6718 - acc: 0.7689
    Epoch 23/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6701 - acc: 0.7700
    Epoch 24/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6709 - acc: 0.7691
    Epoch 25/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6671 - acc: 0.7703
    Epoch 26/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6710 - acc: 0.7698
    Epoch 27/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6663 - acc: 0.7710
    Epoch 28/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6681 - acc: 0.7715
    Epoch 29/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6680 - acc: 0.7689
    Epoch 30/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6703 - acc: 0.7706
    Epoch 31/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6675 - acc: 0.7707
    Epoch 32/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6730 - acc: 0.7691
    Epoch 33/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6679 - acc: 0.7701
    Epoch 34/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6670 - acc: 0.7694
    Epoch 35/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6679 - acc: 0.7709
    Epoch 36/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6689 - acc: 0.7698
    Epoch 37/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6643 - acc: 0.7714
    Epoch 38/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6675 - acc: 0.7710
    Epoch 39/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6679 - acc: 0.7694
    Epoch 40/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6677 - acc: 0.7713
    Epoch 41/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6631 - acc: 0.7714
    Epoch 42/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6655 - acc: 0.7715
    Epoch 43/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.6659 - acc: 0.7712
    Epoch 44/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6626 - acc: 0.7724
    Epoch 45/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6656 - acc: 0.7699
    Epoch 46/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.6646 - acc: 0.7699
    Epoch 47/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6644 - acc: 0.7704
    Epoch 48/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.6639 - acc: 0.7713
    Epoch 49/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6636 - acc: 0.7735
    Epoch 50/100
    15788/15788 [==============================] - 1s 82us/step - loss: 0.6671 - acc: 0.7713
    Epoch 51/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6617 - acc: 0.7724
    Epoch 52/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6637 - acc: 0.7718
    Epoch 53/100
    15788/15788 [==============================] - 1s 81us/step - loss: 0.6613 - acc: 0.7714
    Epoch 54/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6641 - acc: 0.7719
    Epoch 55/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6614 - acc: 0.7727
    Epoch 56/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6644 - acc: 0.7691
    Epoch 57/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6605 - acc: 0.7718
    Epoch 58/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6631 - acc: 0.7712
    Epoch 59/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6615 - acc: 0.7717
    Epoch 60/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6626 - acc: 0.7729
    Epoch 61/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6619 - acc: 0.7725
    Epoch 62/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6604 - acc: 0.7725
    Epoch 63/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6613 - acc: 0.7737
    Epoch 64/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6628 - acc: 0.7727
    Epoch 65/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6619 - acc: 0.7710
    Epoch 66/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6604 - acc: 0.7730
    Epoch 67/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6589 - acc: 0.7727
    Epoch 68/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6576 - acc: 0.7737
    Epoch 69/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6604 - acc: 0.7711
    Epoch 70/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6575 - acc: 0.7711
    Epoch 71/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6595 - acc: 0.7735
    Epoch 72/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6577 - acc: 0.7731
    Epoch 73/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6585 - acc: 0.7722
    Epoch 74/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6599 - acc: 0.7717
    Epoch 75/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6564 - acc: 0.7727
    Epoch 76/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6589 - acc: 0.7731
    Epoch 77/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6554 - acc: 0.7770
    Epoch 78/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6590 - acc: 0.7721
    Epoch 79/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6595 - acc: 0.7729
    Epoch 80/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6559 - acc: 0.7748
    Epoch 81/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6566 - acc: 0.7750
    Epoch 82/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6572 - acc: 0.7728
    Epoch 83/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6543 - acc: 0.7748
    Epoch 84/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6574 - acc: 0.7740
    Epoch 85/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6539 - acc: 0.7730
    Epoch 86/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6551 - acc: 0.7742
    Epoch 87/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6556 - acc: 0.7732
    Epoch 88/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6544 - acc: 0.7734
    Epoch 89/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6555 - acc: 0.7729
    Epoch 90/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6532 - acc: 0.7746
    Epoch 91/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6545 - acc: 0.7744
    Epoch 92/100
    15788/15788 [==============================] - 1s 80us/step - loss: 0.6518 - acc: 0.7743
    Epoch 93/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6540 - acc: 0.7729
    Epoch 94/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6546 - acc: 0.7739
    Epoch 95/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6519 - acc: 0.7749
    Epoch 96/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6524 - acc: 0.7753
    Epoch 97/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6537 - acc: 0.7733
    Epoch 98/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6506 - acc: 0.7758
    Epoch 99/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6527 - acc: 0.7763
    Epoch 100/100
    15788/15788 [==============================] - 1s 79us/step - loss: 0.6493 - acc: 0.7753
    The accuracy(categorical) is: 0.8908031416265518
    The mean squared error is: 32.556371928046616
    


![png](output_10_1.png)


- We thought there may be some kinds of overfitting. So, we turned down the step of iteration with “epochs=100”, “batch_size=512” for each. But the result didn’t change too much. We checked the code for a while, still found nothing wrong.
- Finally, after checked the data again, we realized that the data is not balanced, it is biased. In short, about 77% of the values in column “lights” is zero. That means in most cases, when we build the model with this dataset, the value in that column can be easily predicted when true values are zeros, while provide less guarantee for other values. On the other hand, considering the previous graphs, there are more than 3000 records in a single graph, and the red vertical lines we saw is just a small portion of the values. Although the images are misleading, from the accuracy and mean squared error, we can see that the result is still acceptable.
