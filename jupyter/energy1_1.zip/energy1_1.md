
- This notebook is for training the model for predicting the column "Appliances" while it is considered as categorical data.


```python
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import random as rn
import tensorflow as tf

from keras import backend as K
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.models import load_model
from keras.layers import LSTM
from keras.models import Sequential
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
```

    Using TensorFlow backend.
    


```python
# prepare the functions for evaluating the model
def mse(ar1, ar2):
    return ((ar1 - ar2) ** 2).mean()

def rmse(ar1, ar2):
    return np.sqrt(mse(ar1, ar2))
```


```python
# make the results reproducible
os.environ["PYTHONHASHSEED"] = '0'
np.random.seed(1)
rn.seed(2)
tf.set_random_seed(3)
session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
```


```python
# loading and preprocessing data
energydata_complete = pd.read_csv("energydata_complete.csv").iloc[:, 1:]

energydata_complete = energydata_complete.drop(['lights'], axis=1)

Y = energydata_complete.iloc[:, 0].values

labelencoder_Y_1 = LabelEncoder()
Y_labled = labelencoder_Y_1.fit_transform(Y)

onehotencoder = OneHotEncoder(categorical_features = [0])
Y_onehot = onehotencoder.fit_transform(Y_labled.reshape(Y_labled.shape[0], 1)).toarray()
print(Y_onehot)

Y_columnnames = []
for i in range(Y_onehot.shape[1]):
    if i < 10:
        Y_columnnames.append("Y1_0{0}".format(i))
    else:
        Y_columnnames.append("Y1_{0}".format(i))

Y_onehot = pd.DataFrame(Y_onehot, columns = Y_columnnames)

sc = MinMaxScaler(feature_range = (0, 1))
variables_scaled = pd.DataFrame(sc.fit_transform(energydata_complete.iloc[:, 1:]), columns = list(energydata_complete.iloc[:, 1:].columns))
print(variables_scaled.head())
```

    [[0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     ...
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]]
            T1      RH_1        T2      RH_2        T3      RH_3        T4  \
    0  0.32735  0.566187  0.225345  0.684038  0.215188  0.746066  0.351351   
    1  0.32735  0.541326  0.225345  0.682140  0.215188  0.748871  0.351351   
    2  0.32735  0.530502  0.225345  0.679445  0.215188  0.755569  0.344745   
    3  0.32735  0.524080  0.225345  0.678414  0.215188  0.758685  0.341441   
    4  0.32735  0.531419  0.225345  0.676727  0.215188  0.758685  0.341441   
    
           RH_4        T5      RH_5    ...           T9      RH_9     T_out  \
    0  0.764262  0.175506  0.381691    ...     0.223032  0.677290  0.372990   
    1  0.782437  0.175506  0.381691    ...     0.226500  0.678532  0.369239   
    2  0.778062  0.175506  0.380037    ...     0.219563  0.676049  0.365488   
    3  0.770949  0.175506  0.380037    ...     0.219563  0.671909  0.361736   
    4  0.762697  0.178691  0.380037    ...     0.219563  0.671909  0.357985   
    
       Press_mm_hg    RH_out  Windspeed  Visibility  Tdewpoint       rv1       rv2  
    0     0.097674  0.894737   0.500000    0.953846   0.538462  0.265449  0.265449  
    1     0.100000  0.894737   0.476190    0.894872   0.533937  0.372083  0.372083  
    2     0.102326  0.894737   0.452381    0.835897   0.529412  0.572848  0.572848  
    3     0.104651  0.894737   0.428571    0.776923   0.524887  0.908261  0.908261  
    4     0.106977  0.894737   0.404762    0.717949   0.520362  0.201611  0.201611  
    
    [5 rows x 26 columns]
    

    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\_encoders.py:363: FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
    If you want the future behaviour and silence this warning, you can specify "categories='auto'".
    In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
      warnings.warn(msg, FutureWarning)
    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\_encoders.py:385: DeprecationWarning: The 'categorical_features' keyword is deprecated in version 0.20 and will be removed in 0.22. You can use the ColumnTransformer instead.
      "use the ColumnTransformer instead.", DeprecationWarning)
    


```python
# separate the data into training set and testing set
X_train_scaled = variables_scaled.iloc[:round(np.shape(variables_scaled)[0] * 0.8), :]
Y_train_encoded = Y_onehot.iloc[:round(np.shape(Y_onehot)[0] * 0.8), :]

X_test_scaled = variables_scaled.iloc[round(np.shape(variables_scaled)[0] * 0.8):, :]
Y_test_encoded = Y_onehot.iloc[round(np.shape(Y_onehot)[0] * 0.8):, :]

X_train_scaled = np.reshape(X_train_scaled.values, (X_train_scaled.values.shape[0], X_train_scaled.values.shape[1], 1))
X_test_scaled = np.reshape(X_test_scaled.values, (X_test_scaled.values.shape[0], X_test_scaled.values.shape[1], 1))
```


```python
# Initialising the RNN
layers = Sequential()

# Adding the first LSTM layer and some Dropout regularisation
layers.add(LSTM(units = 64, return_sequences = True, input_shape = (X_train_scaled.shape[1], 1)))
layers.add(Dropout(0.2))

layers.add(Flatten())

# Adding the output layer
layers.add(Dense(Y_train_encoded.shape[1], activation='softmax'))

layers.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
```


```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers1_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 125us/step - loss: 3.0748 - acc: 0.1956
    Epoch 2/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.8575 - acc: 0.2183
    Epoch 3/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.8466 - acc: 0.2162
    Epoch 4/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.8421 - acc: 0.2180
    Epoch 5/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.8361 - acc: 0.2198
    Epoch 6/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.8279 - acc: 0.2195
    Epoch 7/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.8225 - acc: 0.2198
    Epoch 8/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.8127 - acc: 0.2207
    Epoch 9/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7986 - acc: 0.2211
    Epoch 10/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.7825 - acc: 0.2216
    Epoch 11/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7615 - acc: 0.2209
    Epoch 12/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7495 - acc: 0.2223
    Epoch 13/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7375 - acc: 0.2249
    Epoch 14/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7298 - acc: 0.2242
    Epoch 15/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7211 - acc: 0.2256
    Epoch 16/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.7162 - acc: 0.2267
    Epoch 17/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.7062 - acc: 0.2281
    Epoch 18/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6989 - acc: 0.2299
    Epoch 19/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6910 - acc: 0.2297
    Epoch 20/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6880 - acc: 0.2313
    Epoch 21/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6811 - acc: 0.2326
    Epoch 22/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6748 - acc: 0.2320
    Epoch 23/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6687 - acc: 0.2332
    Epoch 24/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6625 - acc: 0.2329
    Epoch 25/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6586 - acc: 0.2378
    Epoch 26/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6503 - acc: 0.2362
    Epoch 27/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6428 - acc: 0.2364
    Epoch 28/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6438 - acc: 0.2408
    Epoch 29/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6357 - acc: 0.2394
    Epoch 30/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6282 - acc: 0.2417
    Epoch 31/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6236 - acc: 0.2406
    Epoch 32/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.6198 - acc: 0.2424
    Epoch 33/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6151 - acc: 0.2399
    Epoch 34/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.6112 - acc: 0.2424
    Epoch 35/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6044 - acc: 0.2455
    Epoch 36/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.6015 - acc: 0.2423
    Epoch 37/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5959 - acc: 0.2430
    Epoch 38/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5920 - acc: 0.2449
    Epoch 39/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5894 - acc: 0.2425
    Epoch 40/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5839 - acc: 0.2428
    Epoch 41/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5839 - acc: 0.2425
    Epoch 42/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5749 - acc: 0.2476
    Epoch 43/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5760 - acc: 0.2477
    Epoch 44/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5722 - acc: 0.2458
    Epoch 45/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5687 - acc: 0.2475
    Epoch 46/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5668 - acc: 0.2475
    Epoch 47/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5634 - acc: 0.2510
    Epoch 48/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5597 - acc: 0.2487
    Epoch 49/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5565 - acc: 0.2484
    Epoch 50/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5512 - acc: 0.2497
    Epoch 51/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5485 - acc: 0.2512
    Epoch 52/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5480 - acc: 0.2463
    Epoch 53/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5427 - acc: 0.2522
    Epoch 54/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5408 - acc: 0.2481
    Epoch 55/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5378 - acc: 0.2523
    Epoch 56/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5348 - acc: 0.2513
    Epoch 57/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5323 - acc: 0.2516
    Epoch 58/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5287 - acc: 0.2535
    Epoch 59/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5269 - acc: 0.2502
    Epoch 60/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5222 - acc: 0.2528
    Epoch 61/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5166 - acc: 0.2531
    Epoch 62/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5153 - acc: 0.2554
    Epoch 63/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5131 - acc: 0.2522
    Epoch 64/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.5095 - acc: 0.2519
    Epoch 65/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5074 - acc: 0.2541
    Epoch 66/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5048 - acc: 0.2552
    Epoch 67/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.5011 - acc: 0.2522
    Epoch 68/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4956 - acc: 0.2573
    Epoch 69/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4955 - acc: 0.2543
    Epoch 70/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4882 - acc: 0.2570
    Epoch 71/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4840 - acc: 0.2576
    Epoch 72/100
    15788/15788 [==============================] - 1s 88us/step - loss: 2.4843 - acc: 0.2563
    Epoch 73/100
    15788/15788 [==============================] - 1s 85us/step - loss: 2.4795 - acc: 0.2558
    Epoch 74/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.4786 - acc: 0.2598
    Epoch 75/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.4700 - acc: 0.2592
    Epoch 76/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.4688 - acc: 0.2624
    Epoch 77/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4633 - acc: 0.2604
    Epoch 78/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.4609 - acc: 0.2638
    Epoch 79/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4568 - acc: 0.2616
    Epoch 80/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4521 - acc: 0.2625
    Epoch 81/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4489 - acc: 0.2635
    Epoch 82/100
    15788/15788 [==============================] - 1s 79us/step - loss: 2.4451 - acc: 0.2642
    Epoch 83/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4404 - acc: 0.2644
    Epoch 84/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4371 - acc: 0.2611
    Epoch 85/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.4349 - acc: 0.2663
    Epoch 86/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.4298 - acc: 0.2637
    Epoch 87/100
    15788/15788 [==============================] - 1s 90us/step - loss: 2.4257 - acc: 0.2655
    Epoch 88/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.4231 - acc: 0.2644
    Epoch 89/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.4175 - acc: 0.2711
    Epoch 90/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.4161 - acc: 0.2743
    Epoch 91/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.4131 - acc: 0.2742
    Epoch 92/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.4109 - acc: 0.2708
    Epoch 93/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.4031 - acc: 0.2758
    Epoch 94/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3980 - acc: 0.2729
    Epoch 95/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3910 - acc: 0.2748
    Epoch 96/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.3947 - acc: 0.2729
    Epoch 97/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3933 - acc: 0.2727
    Epoch 98/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3838 - acc: 0.2797
    Epoch 99/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3823 - acc: 0.2751
    Epoch 100/100
    15788/15788 [==============================] - 1s 84us/step - loss: 2.3749 - acc: 0.2764
    The accuracy(categorical) is: 0.179883455789207
    The mean squared error is: 15055.865214086649
    


![png](output_7_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers1_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.3707 - acc: 0.2769
    Epoch 2/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3702 - acc: 0.2759
    Epoch 3/100
    15788/15788 [==============================] - 1s 90us/step - loss: 2.3635 - acc: 0.2807
    Epoch 4/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.3609 - acc: 0.2843
    Epoch 5/100
    15788/15788 [==============================] - 1s 94us/step - loss: 2.3567 - acc: 0.2798
    Epoch 6/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.3498 - acc: 0.2814
    Epoch 7/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.3478 - acc: 0.2845
    Epoch 8/100
    15788/15788 [==============================] - 1s 88us/step - loss: 2.3424 - acc: 0.2845
    Epoch 9/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3417 - acc: 0.2809
    Epoch 10/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3368 - acc: 0.2857
    Epoch 11/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.3323 - acc: 0.2884
    Epoch 12/100
    15788/15788 [==============================] - 2s 102us/step - loss: 2.3262 - acc: 0.2881
    Epoch 13/100
    15788/15788 [==============================] - 1s 88us/step - loss: 2.3244 - acc: 0.2874
    Epoch 14/100
    15788/15788 [==============================] - 2s 98us/step - loss: 2.3198 - acc: 0.2879
    Epoch 15/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3202 - acc: 0.2872
    Epoch 16/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3203 - acc: 0.2879
    Epoch 17/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.3059 - acc: 0.2902
    Epoch 18/100
    15788/15788 [==============================] - 2s 104us/step - loss: 2.3060 - acc: 0.2893
    Epoch 19/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.3030 - acc: 0.2920
    Epoch 20/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.2983 - acc: 0.2879
    Epoch 21/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2964 - acc: 0.2876
    Epoch 22/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2891 - acc: 0.2945
    Epoch 23/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2841 - acc: 0.2920
    Epoch 24/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.2780 - acc: 0.2981
    Epoch 25/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.2809 - acc: 0.2927
    Epoch 26/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.2794 - acc: 0.2948
    Epoch 27/100
    15788/15788 [==============================] - 2s 96us/step - loss: 2.2764 - acc: 0.2891
    Epoch 28/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.2642 - acc: 0.2943
    Epoch 29/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2574 - acc: 0.3016
    Epoch 30/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.2583 - acc: 0.2985
    Epoch 31/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.2554 - acc: 0.2978
    Epoch 32/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.2477 - acc: 0.2974
    Epoch 33/100
    15788/15788 [==============================] - 1s 84us/step - loss: 2.2491 - acc: 0.2960
    Epoch 34/100
    15788/15788 [==============================] - 2s 109us/step - loss: 2.2445 - acc: 0.2969
    Epoch 35/100
    15788/15788 [==============================] - 2s 101us/step - loss: 2.2367 - acc: 0.2999
    Epoch 36/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.2372 - acc: 0.2985
    Epoch 37/100
    15788/15788 [==============================] - 2s 95us/step - loss: 2.2276 - acc: 0.3004
    Epoch 38/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.2275 - acc: 0.3030
    Epoch 39/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2237 - acc: 0.2980
    Epoch 40/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2199 - acc: 0.2989
    Epoch 41/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2153 - acc: 0.3025
    Epoch 42/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2134 - acc: 0.3044
    Epoch 43/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2053 - acc: 0.3030
    Epoch 44/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.2084 - acc: 0.3007
    Epoch 45/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.2021 - acc: 0.3036
    Epoch 46/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1968 - acc: 0.3047
    Epoch 47/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1932 - acc: 0.3027
    Epoch 48/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.1933 - acc: 0.3031
    Epoch 49/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.1859 - acc: 0.3064
    Epoch 50/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1834 - acc: 0.3064
    Epoch 51/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.1797 - acc: 0.3066
    Epoch 52/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1803 - acc: 0.3066
    Epoch 53/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1698 - acc: 0.3100
    Epoch 54/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.1745 - acc: 0.3086
    Epoch 55/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1611 - acc: 0.3094
    Epoch 56/100
    15788/15788 [==============================] - 2s 100us/step - loss: 2.1604 - acc: 0.3097
    Epoch 57/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.1554 - acc: 0.3144
    Epoch 58/100
    15788/15788 [==============================] - 1s 85us/step - loss: 2.1573 - acc: 0.3110
    Epoch 59/100
    15788/15788 [==============================] - 1s 85us/step - loss: 2.1438 - acc: 0.3142
    Epoch 60/100
    15788/15788 [==============================] - 2s 98us/step - loss: 2.1450 - acc: 0.3150
    Epoch 61/100
    15788/15788 [==============================] - 1s 85us/step - loss: 2.1403 - acc: 0.3123
    Epoch 62/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.1346 - acc: 0.3142
    Epoch 63/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.1422 - acc: 0.3144
    Epoch 64/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.1312 - acc: 0.3142
    Epoch 65/100
    15788/15788 [==============================] - 1s 85us/step - loss: 2.1283 - acc: 0.3157
    Epoch 66/100
    15788/15788 [==============================] - 1s 91us/step - loss: 2.1190 - acc: 0.3197
    Epoch 67/100
    15788/15788 [==============================] - 2s 102us/step - loss: 2.1238 - acc: 0.3125
    Epoch 68/100
    15788/15788 [==============================] - 1s 95us/step - loss: 2.1214 - acc: 0.3180
    Epoch 69/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.1212 - acc: 0.3128
    Epoch 70/100
    15788/15788 [==============================] - 1s 92us/step - loss: 2.1100 - acc: 0.3194
    Epoch 71/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.1098 - acc: 0.3175
    Epoch 72/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.1039 - acc: 0.3182
    Epoch 73/100
    15788/15788 [==============================] - 1s 87us/step - loss: 2.1080 - acc: 0.3177
    Epoch 74/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.1005 - acc: 0.3189
    Epoch 75/100
    15788/15788 [==============================] - 1s 89us/step - loss: 2.0915 - acc: 0.3180
    Epoch 76/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.0933 - acc: 0.3230
    Epoch 77/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0851 - acc: 0.3190
    Epoch 78/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0894 - acc: 0.3231
    Epoch 79/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.0755 - acc: 0.3253
    Epoch 80/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0720 - acc: 0.3251
    Epoch 81/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0795 - acc: 0.3232
    Epoch 82/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0718 - acc: 0.3295
    Epoch 83/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0618 - acc: 0.3236
    Epoch 84/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0678 - acc: 0.3204
    Epoch 85/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.0614 - acc: 0.3240
    Epoch 86/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.0624 - acc: 0.3244
    Epoch 87/100
    15788/15788 [==============================] - 1s 81us/step - loss: 2.0568 - acc: 0.3247
    Epoch 88/100
    15788/15788 [==============================] - 1s 91us/step - loss: 2.0530 - acc: 0.3270
    Epoch 89/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.0562 - acc: 0.3282
    Epoch 90/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.0426 - acc: 0.3292
    Epoch 91/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.0485 - acc: 0.3283
    Epoch 92/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.0436 - acc: 0.3242
    Epoch 93/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0366 - acc: 0.3266
    Epoch 94/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0293 - acc: 0.3319
    Epoch 95/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.0263 - acc: 0.3318
    Epoch 96/100
    15788/15788 [==============================] - 1s 85us/step - loss: 2.0248 - acc: 0.3316
    Epoch 97/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0299 - acc: 0.3302
    Epoch 98/100
    15788/15788 [==============================] - 1s 83us/step - loss: 2.0254 - acc: 0.3270
    Epoch 99/100
    15788/15788 [==============================] - 1s 82us/step - loss: 2.0254 - acc: 0.3325
    Epoch 100/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0156 - acc: 0.3310
    The accuracy(categorical) is: 0.1436534076513808
    The mean squared error is: 20391.563212566507
    


![png](output_8_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers1_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 122us/step - loss: 2.0275 - acc: 0.3273
    Epoch 2/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.0137 - acc: 0.3324
    Epoch 3/100
    15788/15788 [==============================] - 1s 92us/step - loss: 2.0100 - acc: 0.3341
    Epoch 4/100
    15788/15788 [==============================] - 1s 86us/step - loss: 2.0094 - acc: 0.3334
    Epoch 5/100
    15788/15788 [==============================] - 1s 92us/step - loss: 2.0106 - acc: 0.3328
    Epoch 6/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0023 - acc: 0.3353
    Epoch 7/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9940 - acc: 0.3396
    Epoch 8/100
    15788/15788 [==============================] - 1s 80us/step - loss: 2.0016 - acc: 0.3368
    Epoch 9/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9981 - acc: 0.3341
    Epoch 10/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9897 - acc: 0.3395
    Epoch 11/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9846 - acc: 0.3382
    Epoch 12/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9862 - acc: 0.3380
    Epoch 13/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9875 - acc: 0.3353
    Epoch 14/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9848 - acc: 0.3382
    Epoch 15/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9794 - acc: 0.3332
    Epoch 16/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9751 - acc: 0.3391
    Epoch 17/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9735 - acc: 0.3418
    Epoch 18/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9763 - acc: 0.3391
    Epoch 19/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9707 - acc: 0.3405
    Epoch 20/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9622 - acc: 0.3440
    Epoch 21/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9677 - acc: 0.3448
    Epoch 22/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9655 - acc: 0.3446
    Epoch 23/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9565 - acc: 0.3425
    Epoch 24/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9623 - acc: 0.3391
    Epoch 25/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9513 - acc: 0.3403
    Epoch 26/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9561 - acc: 0.3391
    Epoch 27/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9484 - acc: 0.3451
    Epoch 28/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9487 - acc: 0.3455
    Epoch 29/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.9417 - acc: 0.3491
    Epoch 30/100
    15788/15788 [==============================] - 2s 100us/step - loss: 1.9429 - acc: 0.3485
    Epoch 31/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9432 - acc: 0.3453
    Epoch 32/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9423 - acc: 0.3418
    Epoch 33/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9374 - acc: 0.3483
    Epoch 34/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9396 - acc: 0.3466
    Epoch 35/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9331 - acc: 0.3424
    Epoch 36/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9239 - acc: 0.3531
    Epoch 37/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9280 - acc: 0.3464
    Epoch 38/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9237 - acc: 0.3486
    Epoch 39/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9250 - acc: 0.3456
    Epoch 40/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9183 - acc: 0.3512
    Epoch 41/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9220 - acc: 0.3468
    Epoch 42/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9125 - acc: 0.3503
    Epoch 43/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9153 - acc: 0.3493
    Epoch 44/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.9159 - acc: 0.3515
    Epoch 45/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9064 - acc: 0.3531
    Epoch 46/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.9087 - acc: 0.3505
    Epoch 47/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.9090 - acc: 0.3498
    Epoch 48/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.9072 - acc: 0.3488
    Epoch 49/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.9066 - acc: 0.3525
    Epoch 50/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.8971 - acc: 0.3506
    Epoch 51/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.8963 - acc: 0.3559
    Epoch 52/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.8910 - acc: 0.3548
    Epoch 53/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8967 - acc: 0.3523
    Epoch 54/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8845 - acc: 0.3593
    Epoch 55/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8898 - acc: 0.3555
    Epoch 56/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8884 - acc: 0.3548
    Epoch 57/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8835 - acc: 0.3577
    Epoch 58/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8866 - acc: 0.3555
    Epoch 59/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8798 - acc: 0.3550
    Epoch 60/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8768 - acc: 0.3548
    Epoch 61/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8814 - acc: 0.3554
    Epoch 62/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8840 - acc: 0.3533
    Epoch 63/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8700 - acc: 0.3610
    Epoch 64/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8725 - acc: 0.3607
    Epoch 65/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8732 - acc: 0.3619
    Epoch 66/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8615 - acc: 0.3641
    Epoch 67/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8670 - acc: 0.3586
    Epoch 68/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8643 - acc: 0.3607
    Epoch 69/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8645 - acc: 0.3619
    Epoch 70/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8637 - acc: 0.3587
    Epoch 71/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8550 - acc: 0.3627
    Epoch 72/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8539 - acc: 0.3670
    Epoch 73/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8570 - acc: 0.3577
    Epoch 74/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8505 - acc: 0.3634
    Epoch 75/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8503 - acc: 0.3608
    Epoch 76/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8506 - acc: 0.3597
    Epoch 77/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8456 - acc: 0.3626
    Epoch 78/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8435 - acc: 0.3612
    Epoch 79/100
    15788/15788 [==============================] - 1s 91us/step - loss: 1.8452 - acc: 0.3622
    Epoch 80/100
    15788/15788 [==============================] - 1s 90us/step - loss: 1.8425 - acc: 0.3658
    Epoch 81/100
    15788/15788 [==============================] - 1s 89us/step - loss: 1.8409 - acc: 0.3638
    Epoch 82/100
    15788/15788 [==============================] - 1s 88us/step - loss: 1.8400 - acc: 0.3629
    Epoch 83/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8451 - acc: 0.3638
    Epoch 84/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8357 - acc: 0.3684
    Epoch 85/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8308 - acc: 0.3673
    Epoch 86/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8328 - acc: 0.3646
    Epoch 87/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8294 - acc: 0.3702
    Epoch 88/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8256 - acc: 0.3638
    Epoch 89/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8235 - acc: 0.3709
    Epoch 90/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8233 - acc: 0.3675
    Epoch 91/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8238 - acc: 0.3685
    Epoch 92/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8290 - acc: 0.3698
    Epoch 93/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8140 - acc: 0.3676
    Epoch 94/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8189 - acc: 0.3688
    Epoch 95/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8138 - acc: 0.3739
    Epoch 96/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.8151 - acc: 0.3702
    Epoch 97/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8143 - acc: 0.3696
    Epoch 98/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8140 - acc: 0.3698
    Epoch 99/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8055 - acc: 0.3684
    Epoch 100/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8027 - acc: 0.3734
    The accuracy(categorical) is: 0.1608816822903471
    The mean squared error is: 15393.412718520396
    


![png](output_9_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 100, batch_size = 512)

# layers.save('layers1_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 108us/step - loss: 1.8100 - acc: 0.3700
    Epoch 2/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8022 - acc: 0.3758
    Epoch 3/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.8009 - acc: 0.3726
    Epoch 4/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7957 - acc: 0.3755
    Epoch 5/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8067 - acc: 0.3706
    Epoch 6/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7983 - acc: 0.3738
    Epoch 7/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7910 - acc: 0.3751
    Epoch 8/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7997 - acc: 0.3722
    Epoch 9/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.8000 - acc: 0.3719
    Epoch 10/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7844 - acc: 0.3770
    Epoch 11/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7902 - acc: 0.3742
    Epoch 12/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7908 - acc: 0.3742
    Epoch 13/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7843 - acc: 0.3760
    Epoch 14/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7851 - acc: 0.3700
    Epoch 15/100
    15788/15788 [==============================] - 1s 87us/step - loss: 1.7781 - acc: 0.3753
    Epoch 16/100
    15788/15788 [==============================] - 1s 89us/step - loss: 1.7841 - acc: 0.3775
    Epoch 17/100
    15788/15788 [==============================] - 2s 102us/step - loss: 1.7784 - acc: 0.3731
    Epoch 18/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7842 - acc: 0.3750
    Epoch 19/100
    15788/15788 [==============================] - 1s 89us/step - loss: 1.7760 - acc: 0.3811
    Epoch 20/100
    15788/15788 [==============================] - 1s 88us/step - loss: 1.7757 - acc: 0.3769
    Epoch 21/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7716 - acc: 0.3753
    Epoch 22/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7650 - acc: 0.3813
    Epoch 23/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7633 - acc: 0.3778
    Epoch 24/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7720 - acc: 0.3738
    Epoch 25/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7653 - acc: 0.3780
    Epoch 26/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.7686 - acc: 0.3796
    Epoch 27/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.7615 - acc: 0.3797
    Epoch 28/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7617 - acc: 0.3776
    Epoch 29/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7643 - acc: 0.3831
    Epoch 30/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7584 - acc: 0.3833
    Epoch 31/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7532 - acc: 0.3791
    Epoch 32/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7554 - acc: 0.3814
    Epoch 33/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7564 - acc: 0.3819
    Epoch 34/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7563 - acc: 0.3800
    Epoch 35/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7478 - acc: 0.3825
    Epoch 36/100
    15788/15788 [==============================] - 2s 106us/step - loss: 1.7489 - acc: 0.3807
    Epoch 37/100
    15788/15788 [==============================] - 2s 122us/step - loss: 1.7553 - acc: 0.3843
    Epoch 38/100
    15788/15788 [==============================] - 2s 115us/step - loss: 1.7426 - acc: 0.3861
    Epoch 39/100
    15788/15788 [==============================] - 2s 99us/step - loss: 1.7457 - acc: 0.3824
    Epoch 40/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7461 - acc: 0.3838
    Epoch 41/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7384 - acc: 0.3902
    Epoch 42/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7282 - acc: 0.3862
    Epoch 43/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7412 - acc: 0.3821
    Epoch 44/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7407 - acc: 0.3850
    Epoch 45/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7327 - acc: 0.3869
    Epoch 46/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7327 - acc: 0.3843
    Epoch 47/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7326 - acc: 0.3881
    Epoch 48/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7283 - acc: 0.3853
    Epoch 49/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7298 - acc: 0.3909
    Epoch 50/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7386 - acc: 0.3858
    Epoch 51/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7294 - acc: 0.3829
    Epoch 52/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7200 - acc: 0.3867
    Epoch 53/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7209 - acc: 0.3924
    Epoch 54/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7323 - acc: 0.3810
    Epoch 55/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7205 - acc: 0.3869
    Epoch 56/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7219 - acc: 0.3881
    Epoch 57/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7124 - acc: 0.3954
    Epoch 58/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7187 - acc: 0.3900
    Epoch 59/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7206 - acc: 0.3890
    Epoch 60/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7170 - acc: 0.3898
    Epoch 61/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7179 - acc: 0.3887
    Epoch 62/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.7152 - acc: 0.3898
    Epoch 63/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.7154 - acc: 0.3908
    Epoch 64/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7073 - acc: 0.3912
    Epoch 65/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7093 - acc: 0.3911
    Epoch 66/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7001 - acc: 0.3912
    Epoch 67/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7115 - acc: 0.3902
    Epoch 68/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7025 - acc: 0.3921
    Epoch 69/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.7016 - acc: 0.3943
    Epoch 70/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6918 - acc: 0.3980
    Epoch 71/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.6932 - acc: 0.3969
    Epoch 72/100
    15788/15788 [==============================] - 2s 95us/step - loss: 1.6974 - acc: 0.3932
    Epoch 73/100
    15788/15788 [==============================] - 2s 97us/step - loss: 1.6968 - acc: 0.3926
    Epoch 74/100
    15788/15788 [==============================] - 1s 84us/step - loss: 1.6904 - acc: 0.3944
    Epoch 75/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.6968 - acc: 0.3919
    Epoch 76/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6851 - acc: 0.3963
    Epoch 77/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6941 - acc: 0.3949
    Epoch 78/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6951 - acc: 0.3968
    Epoch 79/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.7004 - acc: 0.3959
    Epoch 80/100
    15788/15788 [==============================] - 1s 94us/step - loss: 1.6860 - acc: 0.3994
    Epoch 81/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6959 - acc: 0.3909
    Epoch 82/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6858 - acc: 0.3966
    Epoch 83/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.6877 - acc: 0.3945
    Epoch 84/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6861 - acc: 0.3987
    Epoch 85/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.6781 - acc: 0.3987
    Epoch 86/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.6829 - acc: 0.4035
    Epoch 87/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6810 - acc: 0.3980
    Epoch 88/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6768 - acc: 0.3977
    Epoch 89/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6763 - acc: 0.4001
    Epoch 90/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6704 - acc: 0.4009
    Epoch 91/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.6758 - acc: 0.3995
    Epoch 92/100
    15788/15788 [==============================] - 1s 80us/step - loss: 1.6744 - acc: 0.3991
    Epoch 93/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6677 - acc: 0.4020
    Epoch 94/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6663 - acc: 0.3993
    Epoch 95/100
    15788/15788 [==============================] - 1s 81us/step - loss: 1.6639 - acc: 0.3998
    Epoch 96/100
    15788/15788 [==============================] - 1s 83us/step - loss: 1.6633 - acc: 0.4007
    Epoch 97/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6756 - acc: 0.4016
    Epoch 98/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6758 - acc: 0.3962
    Epoch 99/100
    15788/15788 [==============================] - 1s 86us/step - loss: 1.6668 - acc: 0.4019
    Epoch 100/100
    15788/15788 [==============================] - 1s 82us/step - loss: 1.6648 - acc: 0.4014
    The accuracy(categorical) is: 0.15454775779072713
    The mean squared error is: 24938.408918165696
    


![png](output_10_1.png)


- The result is not ideal, moreover, the accuracy is below 20% and the mean squared error is more than 10000. After 4 iterations it’s still underfitting. So, we conclude this model is not suitable for this scenario.
