
- This notebook is for exploring and visualizing the original data set.
- GitHub Repo: https://github.com/wjx2018neu/71238---ALY-6140---03


```python
import pandas as pd
from datetime import datetime
import calendar
import matplotlib.pyplot as plt
```


```python
# function for converting values in column "date" to unix time stamps
def strtostamp(str):
    datetime_object = datetime.strptime(str, '%Y-%m-%d  %H:%M:%S')
    return calendar.timegm(datetime_object.utctimetuple())
```


```python
energydata_complete = pd.read_csv("energydata_complete.csv")
energydata_complete.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>Appliances</th>
      <th>lights</th>
      <th>T1</th>
      <th>RH_1</th>
      <th>T2</th>
      <th>RH_2</th>
      <th>T3</th>
      <th>RH_3</th>
      <th>T4</th>
      <th>...</th>
      <th>T9</th>
      <th>RH_9</th>
      <th>T_out</th>
      <th>Press_mm_hg</th>
      <th>RH_out</th>
      <th>Windspeed</th>
      <th>Visibility</th>
      <th>Tdewpoint</th>
      <th>rv1</th>
      <th>rv2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016-01-11 17:00:00</td>
      <td>60</td>
      <td>30</td>
      <td>19.89</td>
      <td>47.596667</td>
      <td>19.2</td>
      <td>44.790000</td>
      <td>19.79</td>
      <td>44.730000</td>
      <td>19.000000</td>
      <td>...</td>
      <td>17.033333</td>
      <td>45.53</td>
      <td>6.600000</td>
      <td>733.5</td>
      <td>92.0</td>
      <td>7.000000</td>
      <td>63.000000</td>
      <td>5.3</td>
      <td>13.275433</td>
      <td>13.275433</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2016-01-11 17:10:00</td>
      <td>60</td>
      <td>30</td>
      <td>19.89</td>
      <td>46.693333</td>
      <td>19.2</td>
      <td>44.722500</td>
      <td>19.79</td>
      <td>44.790000</td>
      <td>19.000000</td>
      <td>...</td>
      <td>17.066667</td>
      <td>45.56</td>
      <td>6.483333</td>
      <td>733.6</td>
      <td>92.0</td>
      <td>6.666667</td>
      <td>59.166667</td>
      <td>5.2</td>
      <td>18.606195</td>
      <td>18.606195</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016-01-11 17:20:00</td>
      <td>50</td>
      <td>30</td>
      <td>19.89</td>
      <td>46.300000</td>
      <td>19.2</td>
      <td>44.626667</td>
      <td>19.79</td>
      <td>44.933333</td>
      <td>18.926667</td>
      <td>...</td>
      <td>17.000000</td>
      <td>45.50</td>
      <td>6.366667</td>
      <td>733.7</td>
      <td>92.0</td>
      <td>6.333333</td>
      <td>55.333333</td>
      <td>5.1</td>
      <td>28.642668</td>
      <td>28.642668</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-01-11 17:30:00</td>
      <td>50</td>
      <td>40</td>
      <td>19.89</td>
      <td>46.066667</td>
      <td>19.2</td>
      <td>44.590000</td>
      <td>19.79</td>
      <td>45.000000</td>
      <td>18.890000</td>
      <td>...</td>
      <td>17.000000</td>
      <td>45.40</td>
      <td>6.250000</td>
      <td>733.8</td>
      <td>92.0</td>
      <td>6.000000</td>
      <td>51.500000</td>
      <td>5.0</td>
      <td>45.410389</td>
      <td>45.410389</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016-01-11 17:40:00</td>
      <td>60</td>
      <td>40</td>
      <td>19.89</td>
      <td>46.333333</td>
      <td>19.2</td>
      <td>44.530000</td>
      <td>19.79</td>
      <td>45.000000</td>
      <td>18.890000</td>
      <td>...</td>
      <td>17.000000</td>
      <td>45.40</td>
      <td>6.133333</td>
      <td>733.9</td>
      <td>92.0</td>
      <td>5.666667</td>
      <td>47.666667</td>
      <td>4.9</td>
      <td>10.084097</td>
      <td>10.084097</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
# check if the records in column "date" is correct
for i in range(len(energydata_complete) - 1):
    if strtostamp(energydata_complete.iloc[i, 0]) + 600 != strtostamp(energydata_complete.iloc[i + 1, 0]):
        print("date wrong with index {0}".format(i))
```


```python
energydata_complete.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Appliances</th>
      <th>lights</th>
      <th>T1</th>
      <th>RH_1</th>
      <th>T2</th>
      <th>RH_2</th>
      <th>T3</th>
      <th>RH_3</th>
      <th>T4</th>
      <th>RH_4</th>
      <th>...</th>
      <th>T9</th>
      <th>RH_9</th>
      <th>T_out</th>
      <th>Press_mm_hg</th>
      <th>RH_out</th>
      <th>Windspeed</th>
      <th>Visibility</th>
      <th>Tdewpoint</th>
      <th>rv1</th>
      <th>rv2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>...</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
      <td>19735.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>97.694958</td>
      <td>3.801875</td>
      <td>21.686571</td>
      <td>40.259739</td>
      <td>20.341219</td>
      <td>40.420420</td>
      <td>22.267611</td>
      <td>39.242500</td>
      <td>20.855335</td>
      <td>39.026904</td>
      <td>...</td>
      <td>19.485828</td>
      <td>41.552401</td>
      <td>7.411665</td>
      <td>755.522602</td>
      <td>79.750418</td>
      <td>4.039752</td>
      <td>38.330834</td>
      <td>3.760707</td>
      <td>24.988033</td>
      <td>24.988033</td>
    </tr>
    <tr>
      <th>std</th>
      <td>102.524891</td>
      <td>7.935988</td>
      <td>1.606066</td>
      <td>3.979299</td>
      <td>2.192974</td>
      <td>4.069813</td>
      <td>2.006111</td>
      <td>3.254576</td>
      <td>2.042884</td>
      <td>4.341321</td>
      <td>...</td>
      <td>2.014712</td>
      <td>4.151497</td>
      <td>5.317409</td>
      <td>7.399441</td>
      <td>14.901088</td>
      <td>2.451221</td>
      <td>11.794719</td>
      <td>4.194648</td>
      <td>14.496634</td>
      <td>14.496634</td>
    </tr>
    <tr>
      <th>min</th>
      <td>10.000000</td>
      <td>0.000000</td>
      <td>16.790000</td>
      <td>27.023333</td>
      <td>16.100000</td>
      <td>20.463333</td>
      <td>17.200000</td>
      <td>28.766667</td>
      <td>15.100000</td>
      <td>27.660000</td>
      <td>...</td>
      <td>14.890000</td>
      <td>29.166667</td>
      <td>-5.000000</td>
      <td>729.300000</td>
      <td>24.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>-6.600000</td>
      <td>0.005322</td>
      <td>0.005322</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>50.000000</td>
      <td>0.000000</td>
      <td>20.760000</td>
      <td>37.333333</td>
      <td>18.790000</td>
      <td>37.900000</td>
      <td>20.790000</td>
      <td>36.900000</td>
      <td>19.530000</td>
      <td>35.530000</td>
      <td>...</td>
      <td>18.000000</td>
      <td>38.500000</td>
      <td>3.666667</td>
      <td>750.933333</td>
      <td>70.333333</td>
      <td>2.000000</td>
      <td>29.000000</td>
      <td>0.900000</td>
      <td>12.497889</td>
      <td>12.497889</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>60.000000</td>
      <td>0.000000</td>
      <td>21.600000</td>
      <td>39.656667</td>
      <td>20.000000</td>
      <td>40.500000</td>
      <td>22.100000</td>
      <td>38.530000</td>
      <td>20.666667</td>
      <td>38.400000</td>
      <td>...</td>
      <td>19.390000</td>
      <td>40.900000</td>
      <td>6.916667</td>
      <td>756.100000</td>
      <td>83.666667</td>
      <td>3.666667</td>
      <td>40.000000</td>
      <td>3.433333</td>
      <td>24.897653</td>
      <td>24.897653</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>100.000000</td>
      <td>0.000000</td>
      <td>22.600000</td>
      <td>43.066667</td>
      <td>21.500000</td>
      <td>43.260000</td>
      <td>23.290000</td>
      <td>41.760000</td>
      <td>22.100000</td>
      <td>42.156667</td>
      <td>...</td>
      <td>20.600000</td>
      <td>44.338095</td>
      <td>10.408333</td>
      <td>760.933333</td>
      <td>91.666667</td>
      <td>5.500000</td>
      <td>40.000000</td>
      <td>6.566667</td>
      <td>37.583769</td>
      <td>37.583769</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1080.000000</td>
      <td>70.000000</td>
      <td>26.260000</td>
      <td>63.360000</td>
      <td>29.856667</td>
      <td>56.026667</td>
      <td>29.236000</td>
      <td>50.163333</td>
      <td>26.200000</td>
      <td>51.090000</td>
      <td>...</td>
      <td>24.500000</td>
      <td>53.326667</td>
      <td>26.100000</td>
      <td>772.300000</td>
      <td>100.000000</td>
      <td>14.000000</td>
      <td>66.000000</td>
      <td>15.500000</td>
      <td>49.996530</td>
      <td>49.996530</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 28 columns</p>
</div>




```python
# check if there is any null value
pd.isnull(energydata_complete).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>Appliances</th>
      <th>lights</th>
      <th>T1</th>
      <th>RH_1</th>
      <th>T2</th>
      <th>RH_2</th>
      <th>T3</th>
      <th>RH_3</th>
      <th>T4</th>
      <th>...</th>
      <th>T9</th>
      <th>RH_9</th>
      <th>T_out</th>
      <th>Press_mm_hg</th>
      <th>RH_out</th>
      <th>Windspeed</th>
      <th>Visibility</th>
      <th>Tdewpoint</th>
      <th>rv1</th>
      <th>rv2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
# check if there is any null value
pd.isnull(energydata_complete).sum()
```




    date           0
    Appliances     0
    lights         0
    T1             0
    RH_1           0
    T2             0
    RH_2           0
    T3             0
    RH_3           0
    T4             0
    RH_4           0
    T5             0
    RH_5           0
    T6             0
    RH_6           0
    T7             0
    RH_7           0
    T8             0
    RH_8           0
    T9             0
    RH_9           0
    T_out          0
    Press_mm_hg    0
    RH_out         0
    Windspeed      0
    Visibility     0
    Tdewpoint      0
    rv1            0
    rv2            0
    dtype: int64




```python
# visualizing a sample of columns of "Temperature"
fig, axs = plt.subplots(1, 5, sharey=True)
axs[0].hist(energydata_complete['T1'], bins=20)
axs[1].hist(energydata_complete['T2'], bins=20)
axs[2].hist(energydata_complete['T3'], bins=20)
axs[3].hist(energydata_complete['T4'], bins=20)
axs[4].hist(energydata_complete['T5'], bins=20)
```




    (array([ 228.,  179.,  384.,  991., 1836., 2105., 2287., 2478., 2035.,
            1945., 1802., 1000.,  314.,  354.,  610.,  431.,  639.,   83.,
              17.,   17.]),
     array([15.33   , 15.85325, 16.3765 , 16.89975, 17.423  , 17.94625,
            18.4695 , 18.99275, 19.516  , 20.03925, 20.5625 , 21.08575,
            21.609  , 22.13225, 22.6555 , 23.17875, 23.702  , 24.22525,
            24.7485 , 25.27175, 25.795  ]),
     <a list of 20 Patch objects>)




![png](output_8_1.png)



```python
# visualizing a sample of columns of "Humidity"
fig, axs = plt.subplots(1, 5, sharey=True)
axs[0].hist(energydata_complete['RH_1'], bins=20)
axs[1].hist(energydata_complete['RH_2'], bins=20)
axs[2].hist(energydata_complete['RH_3'], bins=20)
axs[3].hist(energydata_complete['RH_4'], bins=20)
axs[4].hist(energydata_complete['RH_5'], bins=20)
```




    (array([  18.,   25.,  517., 1855., 3943., 4253., 3770., 2167., 1010.,
             540.,  352.,  254.,  200.,  166.,  188.,  173.,  134.,   99.,
              51.,   20.]),
     array([29.815     , 33.14033333, 36.46566667, 39.791     , 43.11633333,
            46.44166667, 49.767     , 53.09233333, 56.41766667, 59.743     ,
            63.06833333, 66.39366667, 69.719     , 73.04433333, 76.36966667,
            79.695     , 83.02033333, 86.34566667, 89.671     , 92.99633333,
            96.32166667]),
     <a list of 20 Patch objects>)




![png](output_9_1.png)



```python
# check the min, max and occurrences in column "Appliances"
print("min of \"Appliances\" is: {0} \nmax of \"Appliances\" is: {1}".format(
energydata_complete["Appliances"].min(),
energydata_complete["Appliances"].max())
)
print(energydata_complete["Appliances"].unique())
print(energydata_complete["Appliances"].value_counts().size)
```

    min of "Appliances" is: 10 
    max of "Appliances" is: 1080
    [  60   50   70  230  580  430  250  100   90   80  140  120  190  110
      400  390  240   40   30  310  380  370   20  260  500  450  220  170
      290  130  200  210  180  350  300  340  150  330  420  520  360  270
      550  690  620  610  490  410  320  740  910  510  790  460  160  480
      280  560 1080  750  470  440  800  540  530  660  630  600   10  570
      830 1070  890  590  850  710  680  670  780  640  650  700  770  720
      760  860  880  730  900  820  870  840]
    92
    


```python
# plot the histogram of column "Appliances"
plt.hist(energydata_complete['Appliances'], bins=20)
```




    (array([1.0744e+04, 5.4940e+03, 1.3590e+03, 3.6400e+02, 4.1900e+02,
            4.2000e+02, 2.8700e+02, 2.0600e+02, 1.4100e+02, 7.1000e+01,
            6.0000e+01, 7.0000e+01, 3.9000e+01, 3.0000e+01, 1.7000e+01,
            7.0000e+00, 5.0000e+00, 0.0000e+00, 0.0000e+00, 2.0000e+00]),
     array([  10. ,   63.5,  117. ,  170.5,  224. ,  277.5,  331. ,  384.5,
             438. ,  491.5,  545. ,  598.5,  652. ,  705.5,  759. ,  812.5,
             866. ,  919.5,  973. , 1026.5, 1080. ]),
     <a list of 20 Patch objects>)




![png](output_11_1.png)



```python
# check the min, max and occurrences in column "lights"
print("min of \"lights\" is: {0} \nmax of \"lights\" is: {1}".format(
energydata_complete["lights"].min(),
energydata_complete["lights"].max())
)
print(energydata_complete["lights"].unique())
print(energydata_complete["lights"].value_counts().size)
```

    min of "lights" is: 0 
    max of "lights" is: 70
    [30 40 50 70 60 10 20  0]
    8
    


```python
# plot the histogram of column "lights"
plt.hist(energydata_complete['lights'], bins=20)
```




    (array([1.5252e+04, 0.0000e+00, 2.2120e+03, 0.0000e+00, 0.0000e+00,
            1.6240e+03, 0.0000e+00, 0.0000e+00, 5.5900e+02, 0.0000e+00,
            0.0000e+00, 7.7000e+01, 0.0000e+00, 0.0000e+00, 9.0000e+00,
            0.0000e+00, 0.0000e+00, 1.0000e+00, 0.0000e+00, 1.0000e+00]),
     array([ 0. ,  3.5,  7. , 10.5, 14. , 17.5, 21. , 24.5, 28. , 31.5, 35. ,
            38.5, 42. , 45.5, 49. , 52.5, 56. , 59.5, 63. , 66.5, 70. ]),
     <a list of 20 Patch objects>)




![png](output_13_1.png)



```python
# check the proportion of "0" in column "lights"
print((energydata_complete['lights'] == 0).sum()/len(energydata_complete))
```

    0.7728401317456296
    


```python

```
