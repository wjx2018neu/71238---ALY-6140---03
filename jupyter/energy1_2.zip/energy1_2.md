
- This notebook is for training the model for predicting the column "Appliances" while it is considered as numerical data.
- GitHub Repo: https://github.com/wjx2018neu/71238---ALY-6140---03


```python
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import random as rn
import tensorflow as tf

from keras import backend as K
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.models import load_model
from keras.layers import LSTM
from keras.models import Sequential
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
```

    Using TensorFlow backend.
    


```python
# prepare the functions for evaluating the model
def mse(ar1, ar2):
    return ((ar1 - ar2) ** 2).mean()

def rmse(ar1, ar2):
    return np.sqrt(mse(ar1, ar2))
```


```python
# make the results reproducible
os.environ["PYTHONHASHSEED"] = '0'
np.random.seed(1)
rn.seed(2)
tf.set_random_seed(3)
session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
```


```python
# loading and preprocessing data
energydata_complete = pd.read_csv("energydata_complete.csv").iloc[:, 1:]

energydata_complete = energydata_complete.drop(['lights'], axis=1)

sc = MinMaxScaler(feature_range = (0, 1))

values_scaled = pd.DataFrame(sc.fit_transform(energydata_complete))
```

    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\data.py:323: DataConversionWarning: Data with input dtype int64, float64 were all converted to float64 by MinMaxScaler.
      return self.partial_fit(X, y)
    


```python
# separate the data into training set and testing set
X_train_scaled = values_scaled.iloc[:round(np.shape(values_scaled)[0] * 0.8), 1:]
Y_train_scaled = values_scaled.iloc[:round(np.shape(values_scaled)[0] * 0.8), 0]

X_test_scaled = values_scaled.iloc[round(np.shape(values_scaled)[0] * 0.8):, 1:]
Y_test_scaled = values_scaled.iloc[round(np.shape(values_scaled)[0] * 0.8):, 0]
Y_test = energydata_complete.iloc[round(np.shape(energydata_complete)[0] * 0.8):, 0].values

X_train_scaled = np.reshape(X_train_scaled.values, (X_train_scaled.values.shape[0], X_train_scaled.values.shape[1], 1))
X_test_scaled = np.reshape(X_test_scaled.values, (X_test_scaled.values.shape[0], X_test_scaled.values.shape[1], 1))
```


```python
# Initialising the RNN
layers = Sequential()

# Adding the first LSTM layer and some Dropout regularisation
layers.add(LSTM(units = 16, return_sequences = True, input_shape = (X_train_scaled.shape[1], 1)))
layers.add(Dropout(0.2))

layers.add(Flatten())

# Adding the output layer
layers.add(Dense(1))

layers.compile(optimizer = 'adam', loss = 'mean_squared_error')
```


```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_scaled, epochs = 100, batch_size = 512)

# layers.save('layers1_2.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_2.h5')

predicted_energy = layers.predict(X_test_scaled)

predicted_inversed = sc.inverse_transform(np.hstack((predicted_energy, np.zeros((predicted_energy.shape[0], np.shape(energydata_complete)[1] - 1)))))[:, 0]
predicted_mse = mse(predicted_inversed, Y_test)
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y_test, color = 'red', label = 'real energy')
plt.plot(predicted_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 3s 160us/step - loss: 0.0124
    Epoch 2/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0106
    Epoch 3/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0102
    Epoch 4/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0099
    Epoch 5/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0097
    Epoch 6/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0097
    Epoch 7/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0095
    Epoch 8/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0095
    Epoch 9/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0094
    Epoch 10/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0094
    Epoch 11/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0093
    Epoch 12/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0093
    Epoch 13/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0093
    Epoch 14/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0092
    Epoch 15/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0092
    Epoch 16/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0091
    Epoch 17/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0091
    Epoch 18/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0091
    Epoch 19/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0091
    Epoch 20/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0090
    Epoch 21/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0090
    Epoch 22/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0090
    Epoch 23/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0090
    Epoch 24/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0090
    Epoch 25/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0090
    Epoch 26/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0090
    Epoch 27/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0089
    Epoch 28/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0089
    Epoch 29/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0089
    Epoch 30/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0089
    Epoch 31/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0089
    Epoch 32/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0089
    Epoch 33/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0088
    Epoch 34/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0089
    Epoch 35/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0088
    Epoch 36/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0088
    Epoch 37/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0088
    Epoch 38/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0088
    Epoch 39/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0088
    Epoch 40/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0088
    Epoch 41/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0087
    Epoch 42/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 43/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 44/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 45/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 46/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 47/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 48/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0087
    Epoch 49/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0087
    Epoch 50/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 51/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0087
    Epoch 52/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0086
    Epoch 53/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 54/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 55/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 56/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 57/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 58/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0086
    Epoch 59/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0086
    Epoch 60/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0086
    Epoch 61/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 62/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 63/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 64/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 65/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0086
    Epoch 66/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0086
    Epoch 67/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 68/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 69/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 70/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0086
    Epoch 71/100
    15788/15788 [==============================] - 2s 102us/step - loss: 0.0085
    Epoch 72/100
    15788/15788 [==============================] - 2s 107us/step - loss: 0.0086
    Epoch 73/100
    15788/15788 [==============================] - 2s 101us/step - loss: 0.0085
    Epoch 74/100
    15788/15788 [==============================] - 2s 99us/step - loss: 0.0085
    Epoch 75/100
    15788/15788 [==============================] - 2s 101us/step - loss: 0.0085
    Epoch 76/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 77/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 78/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0085
    Epoch 79/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0085
    Epoch 80/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 81/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 82/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 83/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 84/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 85/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 86/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 87/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 88/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 89/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 90/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085: 0s - loss: 0.00
    Epoch 91/100
    15788/15788 [==============================] - 2s 96us/step - loss: 0.0085
    Epoch 92/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0085
    Epoch 93/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0085
    Epoch 94/100
    15788/15788 [==============================] - 2s 102us/step - loss: 0.0085
    Epoch 95/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0085
    Epoch 96/100
    15788/15788 [==============================] - 2s 100us/step - loss: 0.0085
    Epoch 97/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 98/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 99/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0084
    Epoch 100/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.0084
    The mean squared error is: 7670.326751774344
    


![png](output_7_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_scaled, epochs = 100, batch_size = 512)

# layers.save('layers1_2.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_2.h5')

predicted_energy = layers.predict(X_test_scaled)

predicted_inversed = sc.inverse_transform(np.hstack((predicted_energy, np.zeros((predicted_energy.shape[0], np.shape(energydata_complete)[1] - 1)))))[:, 0]
predicted_mse = mse(predicted_inversed, Y_test)
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y_test, color = 'red', label = 'real energy')
plt.plot(predicted_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 114us/step - loss: 0.0084
    Epoch 2/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0085
    Epoch 3/100
    15788/15788 [==============================] - 1s 94us/step - loss: 0.0084
    Epoch 4/100
    15788/15788 [==============================] - 2s 120us/step - loss: 0.0085
    Epoch 5/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0084
    Epoch 6/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 7/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0084
    Epoch 8/100
    15788/15788 [==============================] - 2s 105us/step - loss: 0.0085
    Epoch 9/100
    15788/15788 [==============================] - 2s 95us/step - loss: 0.0085
    Epoch 10/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0084
    Epoch 11/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0085
    Epoch 12/100
    15788/15788 [==============================] - 2s 98us/step - loss: 0.0084
    Epoch 13/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 14/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 15/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 16/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 17/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0084
    Epoch 18/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0084
    Epoch 19/100
    15788/15788 [==============================] - 2s 104us/step - loss: 0.0084
    Epoch 20/100
    15788/15788 [==============================] - 2s 105us/step - loss: 0.0084
    Epoch 21/100
    15788/15788 [==============================] - 2s 115us/step - loss: 0.0084
    Epoch 22/100
    15788/15788 [==============================] - 2s 104us/step - loss: 0.0084
    Epoch 23/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0084
    Epoch 24/100
    15788/15788 [==============================] - 2s 99us/step - loss: 0.0084
    Epoch 25/100
    15788/15788 [==============================] - 2s 103us/step - loss: 0.0084
    Epoch 26/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0084
    Epoch 27/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0084
    Epoch 28/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0084
    Epoch 29/100
    15788/15788 [==============================] - 2s 114us/step - loss: 0.0084
    Epoch 30/100
    15788/15788 [==============================] - 2s 98us/step - loss: 0.0084
    Epoch 31/100
    15788/15788 [==============================] - 2s 110us/step - loss: 0.0084
    Epoch 32/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 33/100
    15788/15788 [==============================] - 2s 98us/step - loss: 0.0084
    Epoch 34/100
    15788/15788 [==============================] - 2s 95us/step - loss: 0.0084
    Epoch 35/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0084
    Epoch 36/100
    15788/15788 [==============================] - 2s 101us/step - loss: 0.0084
    Epoch 37/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0084
    Epoch 38/100
    15788/15788 [==============================] - 2s 116us/step - loss: 0.0084
    Epoch 39/100
    15788/15788 [==============================] - 2s 103us/step - loss: 0.0084
    Epoch 40/100
    15788/15788 [==============================] - 2s 101us/step - loss: 0.0084
    Epoch 41/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0084
    Epoch 42/100
    15788/15788 [==============================] - 2s 105us/step - loss: 0.0084
    Epoch 43/100
    15788/15788 [==============================] - 2s 99us/step - loss: 0.0084
    Epoch 44/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.0083
    Epoch 45/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0084
    Epoch 46/100
    15788/15788 [==============================] - 2s 111us/step - loss: 0.0084
    Epoch 47/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0083
    Epoch 48/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0084
    Epoch 49/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0084
    Epoch 50/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0083
    Epoch 51/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0084
    Epoch 52/100
    15788/15788 [==============================] - 2s 96us/step - loss: 0.0084
    Epoch 53/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0083
    Epoch 54/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0083
    Epoch 55/100
    15788/15788 [==============================] - 1s 95us/step - loss: 0.0084
    Epoch 56/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 57/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.0084
    Epoch 58/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0083
    Epoch 59/100
    15788/15788 [==============================] - 2s 112us/step - loss: 0.0083
    Epoch 60/100
    15788/15788 [==============================] - 2s 105us/step - loss: 0.0083
    Epoch 61/100
    15788/15788 [==============================] - 2s 102us/step - loss: 0.0083
    Epoch 62/100
    15788/15788 [==============================] - 2s 102us/step - loss: 0.0083
    Epoch 63/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 64/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 65/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0083
    Epoch 66/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0083
    Epoch 67/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 68/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 69/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 70/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 71/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 72/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 73/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0083
    Epoch 74/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0083
    Epoch 75/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0083
    Epoch 76/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 77/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 78/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 79/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 80/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 81/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 82/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 83/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 84/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 85/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 86/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 87/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0083
    Epoch 88/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 89/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 90/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0083
    Epoch 91/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 92/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 93/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0082
    Epoch 94/100
    15788/15788 [==============================] - 1s 88us/step - loss: 0.0082
    Epoch 95/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0082
    Epoch 96/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 97/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 98/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 99/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0082
    Epoch 100/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    The mean squared error is: 7629.418491753409
    


![png](output_8_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_scaled, epochs = 100, batch_size = 512)

# layers.save('layers1_2.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_2.h5')

predicted_energy = layers.predict(X_test_scaled)

predicted_inversed = sc.inverse_transform(np.hstack((predicted_energy, np.zeros((predicted_energy.shape[0], np.shape(energydata_complete)[1] - 1)))))[:, 0]
predicted_mse = mse(predicted_inversed, Y_test)
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y_test, color = 'red', label = 'real energy')
plt.plot(predicted_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 115us/step - loss: 0.0082
    Epoch 2/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 3/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 4/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 5/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 6/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 7/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 8/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 9/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 10/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 11/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 12/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 13/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 14/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0082
    Epoch 15/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0082
    Epoch 16/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 17/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0082
    Epoch 18/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0082
    Epoch 19/100
    15788/15788 [==============================] - 2s 116us/step - loss: 0.0081
    Epoch 20/100
    15788/15788 [==============================] - 2s 98us/step - loss: 0.0082
    Epoch 21/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0081
    Epoch 22/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 23/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 24/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 25/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 26/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 27/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 28/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 29/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 30/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 31/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 32/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 33/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.0081
    Epoch 34/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 35/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 36/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 37/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 38/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 39/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 40/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 41/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 42/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 43/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0081
    Epoch 44/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 45/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 46/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 47/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 48/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 49/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0081
    Epoch 50/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0080
    Epoch 51/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0080
    Epoch 52/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0081
    Epoch 53/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 54/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0081
    Epoch 55/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 56/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0080
    Epoch 57/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0080
    Epoch 58/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 59/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 60/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 61/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 62/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0080
    Epoch 63/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 64/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 65/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 66/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 67/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 68/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 69/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 70/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 71/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 72/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 73/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 74/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 75/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 76/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 77/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 78/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 79/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 80/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 81/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 82/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 83/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0080
    Epoch 84/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 85/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 86/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 87/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 88/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 89/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 90/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 91/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 92/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 93/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 94/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 95/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 96/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 97/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 98/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0079
    Epoch 99/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 100/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    The mean squared error is: 9416.750288733538
    


![png](output_9_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_scaled, epochs = 100, batch_size = 512)

# layers.save('layers1_2.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers1_2.h5')

predicted_energy = layers.predict(X_test_scaled)

predicted_inversed = sc.inverse_transform(np.hstack((predicted_energy, np.zeros((predicted_energy.shape[0], np.shape(energydata_complete)[1] - 1)))))[:, 0]
predicted_mse = mse(predicted_inversed, Y_test)
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y_test, color = 'red', label = 'real energy')
plt.plot(predicted_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/100
    15788/15788 [==============================] - 2s 114us/step - loss: 0.0079
    Epoch 2/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 3/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 4/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 5/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 6/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 7/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 8/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 9/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 10/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 11/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 12/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 13/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 14/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 15/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 16/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 17/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 18/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 19/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 20/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 21/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 22/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 23/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 24/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 25/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 26/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 27/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 28/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 29/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 30/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 31/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0079
    Epoch 32/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 33/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 34/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 35/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 36/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 37/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 38/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 39/100
    15788/15788 [==============================] - 2s 109us/step - loss: 0.0078
    Epoch 40/100
    15788/15788 [==============================] - 2s 97us/step - loss: 0.0077
    Epoch 41/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 42/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0079
    Epoch 43/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 44/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 45/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 46/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 47/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 48/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 49/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 50/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 51/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 52/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 53/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 54/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0077
    Epoch 55/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 56/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 57/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0078
    Epoch 58/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0077
    Epoch 59/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 60/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 61/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 62/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 63/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0077
    Epoch 64/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0078
    Epoch 65/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 66/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 67/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 68/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 69/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0077
    Epoch 70/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 71/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0078
    Epoch 72/100
    15788/15788 [==============================] - 2s 118us/step - loss: 0.0078
    Epoch 73/100
    15788/15788 [==============================] - 2s 99us/step - loss: 0.0078
    Epoch 74/100
    15788/15788 [==============================] - 1s 94us/step - loss: 0.0078
    Epoch 75/100
    15788/15788 [==============================] - 1s 93us/step - loss: 0.0077
    Epoch 76/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0077
    Epoch 77/100
    15788/15788 [==============================] - 1s 95us/step - loss: 0.0078
    Epoch 78/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 79/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 80/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 81/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0077
    Epoch 82/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 83/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 84/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0078
    Epoch 85/100
    15788/15788 [==============================] - 1s 89us/step - loss: 0.0077
    Epoch 86/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0077
    Epoch 87/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0077
    Epoch 88/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0077
    Epoch 89/100
    15788/15788 [==============================] - 1s 90us/step - loss: 0.0078
    Epoch 90/100
    15788/15788 [==============================] - 2s 96us/step - loss: 0.0077
    Epoch 91/100
    15788/15788 [==============================] - 2s 100us/step - loss: 0.0077
    Epoch 92/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    Epoch 93/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    Epoch 94/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    Epoch 95/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    Epoch 96/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    Epoch 97/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    Epoch 98/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0077
    Epoch 99/100
    15788/15788 [==============================] - 1s 91us/step - loss: 0.0077
    Epoch 100/100
    15788/15788 [==============================] - 1s 92us/step - loss: 0.0077
    The mean squared error is: 11068.051938180297
    


![png](output_10_1.png)


- From the results we can see that, at the end of the 2nd iteration, the mean squared error reaches 7629, much lower than the previous results, then it starts to overfit. Considering the range of this variable, prediction with root mean squared error below 90 is acceptable. For many values in the graph, our prediction only catches the trend, there are large gaps between the magnitudes. If we need to get a more precise model, more layer may be needed for extracting more deeper information. That is time consuming and we are planning to accomplish it in the future when we become more experienced.
