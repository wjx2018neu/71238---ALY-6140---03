
- This notebook is for training the model for predicting the column "lights" while it is considered as categorical data, with "epochs = 200, batch_size = 2048".
- GitHub Repo: https://github.com/wjx2018neu/71238---ALY-6140---03


```python
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import random as rn
import tensorflow as tf

from keras import backend as K
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.models import load_model
from keras.layers import LSTM
from keras.models import Sequential
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
```

    Using TensorFlow backend.
    


```python
# prepare the functions for evaluating the model
def mse(ar1, ar2):
    return ((ar1 - ar2) ** 2).mean()

def rmse(ar1, ar2):
    return np.sqrt(mse(ar1, ar2))
```


```python
# make the results reproducible
os.environ["PYTHONHASHSEED"] = '0'
np.random.seed(1)
rn.seed(2)
tf.set_random_seed(3)
session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
K.set_session(sess)
```


```python
# loading and preprocessing data
energydata_complete = pd.read_csv("energydata_complete.csv").iloc[:, 1:]

energydata_complete = energydata_complete.drop(['Appliances'], axis=1)

Y = energydata_complete.iloc[:, 0].values

labelencoder_Y_1 = LabelEncoder()
Y_labled = labelencoder_Y_1.fit_transform(Y)

onehotencoder = OneHotEncoder(categorical_features = [0])
Y_onehot = onehotencoder.fit_transform(Y_labled.reshape(Y_labled.shape[0], 1)).toarray()
print(Y_onehot)

Y_columnnames = []
for i in range(Y_onehot.shape[1]):
    if i < 10:
        Y_columnnames.append("Y1_0{0}".format(i))
    else:
        Y_columnnames.append("Y1_{0}".format(i))

Y_onehot = pd.DataFrame(Y_onehot, columns = Y_columnnames)

sc = MinMaxScaler(feature_range = (0, 1))
variables_scaled = pd.DataFrame(sc.fit_transform(energydata_complete.iloc[:, 1:]), columns = list(energydata_complete.iloc[:, 1:].columns))
print(variables_scaled.head())
```

    [[0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     [0. 0. 0. ... 0. 0. 0.]
     ...
     [0. 1. 0. ... 0. 0. 0.]
     [0. 1. 0. ... 0. 0. 0.]
     [0. 1. 0. ... 0. 0. 0.]]
            T1      RH_1        T2      RH_2        T3      RH_3        T4  \
    0  0.32735  0.566187  0.225345  0.684038  0.215188  0.746066  0.351351   
    1  0.32735  0.541326  0.225345  0.682140  0.215188  0.748871  0.351351   
    2  0.32735  0.530502  0.225345  0.679445  0.215188  0.755569  0.344745   
    3  0.32735  0.524080  0.225345  0.678414  0.215188  0.758685  0.341441   
    4  0.32735  0.531419  0.225345  0.676727  0.215188  0.758685  0.341441   
    
           RH_4        T5      RH_5    ...           T9      RH_9     T_out  \
    0  0.764262  0.175506  0.381691    ...     0.223032  0.677290  0.372990   
    1  0.782437  0.175506  0.381691    ...     0.226500  0.678532  0.369239   
    2  0.778062  0.175506  0.380037    ...     0.219563  0.676049  0.365488   
    3  0.770949  0.175506  0.380037    ...     0.219563  0.671909  0.361736   
    4  0.762697  0.178691  0.380037    ...     0.219563  0.671909  0.357985   
    
       Press_mm_hg    RH_out  Windspeed  Visibility  Tdewpoint       rv1       rv2  
    0     0.097674  0.894737   0.500000    0.953846   0.538462  0.265449  0.265449  
    1     0.100000  0.894737   0.476190    0.894872   0.533937  0.372083  0.372083  
    2     0.102326  0.894737   0.452381    0.835897   0.529412  0.572848  0.572848  
    3     0.104651  0.894737   0.428571    0.776923   0.524887  0.908261  0.908261  
    4     0.106977  0.894737   0.404762    0.717949   0.520362  0.201611  0.201611  
    
    [5 rows x 26 columns]
    

    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\_encoders.py:363: FutureWarning: The handling of integer data will change in version 0.22. Currently, the categories are determined based on the range [0, max(values)], while in the future they will be determined based on the unique values.
    If you want the future behaviour and silence this warning, you can specify "categories='auto'".
    In case you used a LabelEncoder before this OneHotEncoder to convert the categories to integers, then you can now use the OneHotEncoder directly.
      warnings.warn(msg, FutureWarning)
    d:\programfilesnospace\miniconda3\envs\py365-tfgpu\lib\site-packages\sklearn\preprocessing\_encoders.py:385: DeprecationWarning: The 'categorical_features' keyword is deprecated in version 0.20 and will be removed in 0.22. You can use the ColumnTransformer instead.
      "use the ColumnTransformer instead.", DeprecationWarning)
    


```python
# separate the data into training set and testing set
X_train_scaled = variables_scaled.iloc[:round(np.shape(variables_scaled)[0] * 0.8), :]
Y_train_encoded = Y_onehot.iloc[:round(np.shape(Y_onehot)[0] * 0.8), :]

X_test_scaled = variables_scaled.iloc[round(np.shape(variables_scaled)[0] * 0.8):, :]
Y_test_encoded = Y_onehot.iloc[round(np.shape(Y_onehot)[0] * 0.8):, :]

X_train_scaled = np.reshape(X_train_scaled.values, (X_train_scaled.values.shape[0], X_train_scaled.values.shape[1], 1))
X_test_scaled = np.reshape(X_test_scaled.values, (X_test_scaled.values.shape[0], X_test_scaled.values.shape[1], 1))
```


```python
# Initialising the RNN
layers = Sequential()

# Adding the first LSTM layer and some Dropout regularisation
layers.add(LSTM(units = 16, return_sequences = True, input_shape = (X_train_scaled.shape[1], 1)))
layers.add(Dropout(0.2))

layers.add(Flatten())

# Adding the output layer
layers.add(Dense(Y_train_encoded.shape[1], activation='softmax'))

layers.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
```


```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 200, batch_size = 2048)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/200
    15788/15788 [==============================] - 1s 67us/step - loss: 1.7645 - acc: 0.6027
    Epoch 2/200
    15788/15788 [==============================] - 0s 20us/step - loss: 1.1461 - acc: 0.7432
    Epoch 3/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.9261 - acc: 0.7432
    Epoch 4/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8885 - acc: 0.7432
    Epoch 5/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8764 - acc: 0.7432
    Epoch 6/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8733 - acc: 0.7432
    Epoch 7/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8661 - acc: 0.7432
    Epoch 8/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8664 - acc: 0.7432
    Epoch 9/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8629 - acc: 0.7432
    Epoch 10/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8621 - acc: 0.7432
    Epoch 11/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8584 - acc: 0.7432
    Epoch 12/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8591 - acc: 0.7432
    Epoch 13/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8580 - acc: 0.7432
    Epoch 14/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8572 - acc: 0.7432
    Epoch 15/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8568 - acc: 0.7432
    Epoch 16/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8546 - acc: 0.7432
    Epoch 17/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8551 - acc: 0.7432
    Epoch 18/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8541 - acc: 0.7432
    Epoch 19/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8517 - acc: 0.7432
    Epoch 20/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8496 - acc: 0.7432
    Epoch 21/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8530 - acc: 0.7432
    Epoch 22/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8516 - acc: 0.7432
    Epoch 23/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8504 - acc: 0.7432
    Epoch 24/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8498 - acc: 0.7432
    Epoch 25/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.8489 - acc: 0.7432
    Epoch 26/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8470 - acc: 0.7432
    Epoch 27/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8478 - acc: 0.7432
    Epoch 28/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.8463 - acc: 0.7432
    Epoch 29/200
    15788/15788 [==============================] - 0s 27us/step - loss: 0.8442 - acc: 0.7432
    Epoch 30/200
    15788/15788 [==============================] - 0s 26us/step - loss: 0.8427 - acc: 0.7432
    Epoch 31/200
    15788/15788 [==============================] - 0s 29us/step - loss: 0.8447 - acc: 0.7432
    Epoch 32/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8421 - acc: 0.7432
    Epoch 33/200
    15788/15788 [==============================] - 0s 27us/step - loss: 0.8421 - acc: 0.7432
    Epoch 34/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8401 - acc: 0.7432
    Epoch 35/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8386 - acc: 0.7432
    Epoch 36/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8380 - acc: 0.7432
    Epoch 37/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8393 - acc: 0.7432
    Epoch 38/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8362 - acc: 0.7432
    Epoch 39/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8336 - acc: 0.7432
    Epoch 40/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8335 - acc: 0.7432
    Epoch 41/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8347 - acc: 0.7432
    Epoch 42/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8335 - acc: 0.7432
    Epoch 43/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8316 - acc: 0.7432
    Epoch 44/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8301 - acc: 0.7432
    Epoch 45/200
    15788/15788 [==============================] - 0s 28us/step - loss: 0.8300 - acc: 0.7432
    Epoch 46/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8301 - acc: 0.7432
    Epoch 47/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8270 - acc: 0.7432
    Epoch 48/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8258 - acc: 0.7433
    Epoch 49/200
    15788/15788 [==============================] - 0s 29us/step - loss: 0.8261 - acc: 0.7433
    Epoch 50/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8246 - acc: 0.7433: 0s - loss: 0.8435 - acc: 0.7
    Epoch 51/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8245 - acc: 0.7433
    Epoch 52/200
    15788/15788 [==============================] - 0s 28us/step - loss: 0.8213 - acc: 0.7435
    Epoch 53/200
    15788/15788 [==============================] - 0s 27us/step - loss: 0.8194 - acc: 0.7433
    Epoch 54/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8242 - acc: 0.7436
    Epoch 55/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8186 - acc: 0.7433
    Epoch 56/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8197 - acc: 0.7433
    Epoch 57/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8181 - acc: 0.7434
    Epoch 58/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8193 - acc: 0.7435
    Epoch 59/200
    15788/15788 [==============================] - 0s 29us/step - loss: 0.8182 - acc: 0.7425
    Epoch 60/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8156 - acc: 0.7435
    Epoch 61/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8180 - acc: 0.7439
    Epoch 62/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8140 - acc: 0.7433
    Epoch 63/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8162 - acc: 0.7432
    Epoch 64/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8138 - acc: 0.7430
    Epoch 65/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8139 - acc: 0.7436
    Epoch 66/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8144 - acc: 0.7435
    Epoch 67/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8129 - acc: 0.7433
    Epoch 68/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8129 - acc: 0.7437
    Epoch 69/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8091 - acc: 0.7433
    Epoch 70/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8111 - acc: 0.7434
    Epoch 71/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8092 - acc: 0.7430
    Epoch 72/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8108 - acc: 0.7430
    Epoch 73/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.8079 - acc: 0.7435
    Epoch 74/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8067 - acc: 0.7431
    Epoch 75/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.8090 - acc: 0.7428
    Epoch 76/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8061 - acc: 0.7434
    Epoch 77/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8079 - acc: 0.7427
    Epoch 78/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.8073 - acc: 0.7432
    Epoch 79/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8044 - acc: 0.7440
    Epoch 80/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8046 - acc: 0.7426
    Epoch 81/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8057 - acc: 0.7432
    Epoch 82/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8021 - acc: 0.7432
    Epoch 83/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8014 - acc: 0.7437
    Epoch 84/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.8044 - acc: 0.7425
    Epoch 85/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.8005 - acc: 0.7442
    Epoch 86/200
    15788/15788 [==============================] - 0s 24us/step - loss: 0.8000 - acc: 0.7433
    Epoch 87/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.8019 - acc: 0.7435
    Epoch 88/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.7976 - acc: 0.7433
    Epoch 89/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7969 - acc: 0.7442
    Epoch 90/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7977 - acc: 0.7439
    Epoch 91/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7964 - acc: 0.7429
    Epoch 92/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.7969 - acc: 0.7431
    Epoch 93/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7958 - acc: 0.7433
    Epoch 94/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7949 - acc: 0.7434
    Epoch 95/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7931 - acc: 0.7433
    Epoch 96/200
    15788/15788 [==============================] - 0s 26us/step - loss: 0.7949 - acc: 0.7430
    Epoch 97/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7923 - acc: 0.7432
    Epoch 98/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7927 - acc: 0.7436
    Epoch 99/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7931 - acc: 0.7434
    Epoch 100/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7913 - acc: 0.7430
    Epoch 101/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7909 - acc: 0.7447
    Epoch 102/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7903 - acc: 0.7434
    Epoch 103/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7910 - acc: 0.7443
    Epoch 104/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7883 - acc: 0.7435
    Epoch 105/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7897 - acc: 0.7443
    Epoch 106/200
    15788/15788 [==============================] - 0s 26us/step - loss: 0.7877 - acc: 0.7443
    Epoch 107/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7865 - acc: 0.7446
    Epoch 108/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7844 - acc: 0.7446
    Epoch 109/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7873 - acc: 0.7445
    Epoch 110/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7851 - acc: 0.7444
    Epoch 111/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.7858 - acc: 0.7447
    Epoch 112/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7829 - acc: 0.7454
    Epoch 113/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7858 - acc: 0.7453
    Epoch 114/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7833 - acc: 0.7449
    Epoch 115/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7831 - acc: 0.7446
    Epoch 116/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.7821 - acc: 0.7449
    Epoch 117/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.7810 - acc: 0.7452
    Epoch 118/200
    15788/15788 [==============================] - 0s 25us/step - loss: 0.7825 - acc: 0.7445
    Epoch 119/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7817 - acc: 0.7454
    Epoch 120/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7793 - acc: 0.7460
    Epoch 121/200
    15788/15788 [==============================] - 0s 28us/step - loss: 0.7801 - acc: 0.7452
    Epoch 122/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.7780 - acc: 0.7452
    Epoch 123/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7779 - acc: 0.7463
    Epoch 124/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7780 - acc: 0.7461
    Epoch 125/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7786 - acc: 0.7453
    Epoch 126/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7761 - acc: 0.7461
    Epoch 127/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7788 - acc: 0.7452
    Epoch 128/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7746 - acc: 0.7452
    Epoch 129/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7747 - acc: 0.7459
    Epoch 130/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7759 - acc: 0.7463
    Epoch 131/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7743 - acc: 0.7470
    Epoch 132/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7755 - acc: 0.7460
    Epoch 133/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7725 - acc: 0.7468
    Epoch 134/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7737 - acc: 0.7471
    Epoch 135/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7734 - acc: 0.7463
    Epoch 136/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7711 - acc: 0.7470
    Epoch 137/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7726 - acc: 0.7463
    Epoch 138/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7706 - acc: 0.7462
    Epoch 139/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7712 - acc: 0.7470
    Epoch 140/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7726 - acc: 0.7469
    Epoch 141/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7705 - acc: 0.7477
    Epoch 142/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7681 - acc: 0.7481
    Epoch 143/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7678 - acc: 0.7478
    Epoch 144/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7684 - acc: 0.7482
    Epoch 145/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7713 - acc: 0.7468
    Epoch 146/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7690 - acc: 0.7474
    Epoch 147/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7664 - acc: 0.7480
    Epoch 148/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7662 - acc: 0.7475
    Epoch 149/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7675 - acc: 0.7472
    Epoch 150/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7659 - acc: 0.7477
    Epoch 151/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7638 - acc: 0.7492
    Epoch 152/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7647 - acc: 0.7477
    Epoch 153/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7643 - acc: 0.7482
    Epoch 154/200
    15788/15788 [==============================] - 0s 25us/step - loss: 0.7662 - acc: 0.7485
    Epoch 155/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.7630 - acc: 0.7483
    Epoch 156/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.7634 - acc: 0.7496
    Epoch 157/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7621 - acc: 0.7484
    Epoch 158/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7616 - acc: 0.7489
    Epoch 159/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7606 - acc: 0.7497
    Epoch 160/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.7600 - acc: 0.7484
    Epoch 161/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7625 - acc: 0.7488
    Epoch 162/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7606 - acc: 0.7485
    Epoch 163/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7597 - acc: 0.7490
    Epoch 164/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7609 - acc: 0.7498
    Epoch 165/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7587 - acc: 0.7506
    Epoch 166/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7587 - acc: 0.7498
    Epoch 167/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7575 - acc: 0.7494
    Epoch 168/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7586 - acc: 0.7497
    Epoch 169/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7558 - acc: 0.7494
    Epoch 170/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7573 - acc: 0.7498
    Epoch 171/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7578 - acc: 0.7503
    Epoch 172/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7545 - acc: 0.7499
    Epoch 173/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7549 - acc: 0.7513
    Epoch 174/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7555 - acc: 0.7514
    Epoch 175/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7544 - acc: 0.7510
    Epoch 176/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7535 - acc: 0.7513
    Epoch 177/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7526 - acc: 0.7504
    Epoch 178/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7527 - acc: 0.7513
    Epoch 179/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7491 - acc: 0.7518
    Epoch 180/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7501 - acc: 0.7514
    Epoch 181/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7522 - acc: 0.7518
    Epoch 182/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7493 - acc: 0.7504
    Epoch 183/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7508 - acc: 0.7513
    Epoch 184/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7489 - acc: 0.7516
    Epoch 185/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7518 - acc: 0.7527
    Epoch 186/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7467 - acc: 0.7525
    Epoch 187/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7467 - acc: 0.7523
    Epoch 188/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7500 - acc: 0.7516
    Epoch 189/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.7470 - acc: 0.7518
    Epoch 190/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7454 - acc: 0.7523
    Epoch 191/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7490 - acc: 0.7515
    Epoch 192/200
    15788/15788 [==============================] - 0s 24us/step - loss: 0.7462 - acc: 0.7529
    Epoch 193/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7464 - acc: 0.7516
    Epoch 194/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7487 - acc: 0.7510
    Epoch 195/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7431 - acc: 0.7534
    Epoch 196/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7466 - acc: 0.7520
    Epoch 197/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7469 - acc: 0.7516
    Epoch 198/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7434 - acc: 0.7523
    Epoch 199/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7423 - acc: 0.7541
    Epoch 200/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7438 - acc: 0.7534
    The accuracy(categorical) is: 0.8849759310869014
    The mean squared error is: 34.659234861920446
    


![png](output_7_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 200, batch_size = 2048)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/200
    15788/15788 [==============================] - 1s 49us/step - loss: 0.7429 - acc: 0.7525
    Epoch 2/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7418 - acc: 0.7528
    Epoch 3/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7411 - acc: 0.7540
    Epoch 4/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7407 - acc: 0.7536
    Epoch 5/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7424 - acc: 0.7536
    Epoch 6/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7423 - acc: 0.7530
    Epoch 7/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7425 - acc: 0.7532
    Epoch 8/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7407 - acc: 0.7549
    Epoch 9/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7407 - acc: 0.7541
    Epoch 10/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7389 - acc: 0.7549
    Epoch 11/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7393 - acc: 0.7537
    Epoch 12/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7363 - acc: 0.7537
    Epoch 13/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7353 - acc: 0.7548
    Epoch 14/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7386 - acc: 0.7542
    Epoch 15/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7364 - acc: 0.7541
    Epoch 16/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7366 - acc: 0.7552
    Epoch 17/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7364 - acc: 0.7556
    Epoch 18/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7402 - acc: 0.7540
    Epoch 19/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7359 - acc: 0.7560
    Epoch 20/200
    15788/15788 [==============================] - 0s 26us/step - loss: 0.7378 - acc: 0.7563
    Epoch 21/200
    15788/15788 [==============================] - 1s 48us/step - loss: 0.7375 - acc: 0.7540
    Epoch 22/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7367 - acc: 0.7546
    Epoch 23/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7365 - acc: 0.7576
    Epoch 24/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7341 - acc: 0.7564
    Epoch 25/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7353 - acc: 0.7544
    Epoch 26/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7357 - acc: 0.7539
    Epoch 27/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7314 - acc: 0.7562
    Epoch 28/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7339 - acc: 0.7557
    Epoch 29/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7313 - acc: 0.7549
    Epoch 30/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7325 - acc: 0.7571
    Epoch 31/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7315 - acc: 0.7561
    Epoch 32/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7334 - acc: 0.7569
    Epoch 33/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7305 - acc: 0.7567
    Epoch 34/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7321 - acc: 0.7549
    Epoch 35/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7304 - acc: 0.7574
    Epoch 36/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7276 - acc: 0.7580
    Epoch 37/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7330 - acc: 0.7553
    Epoch 38/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7313 - acc: 0.7583
    Epoch 39/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7293 - acc: 0.7575
    Epoch 40/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7299 - acc: 0.7567
    Epoch 41/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7278 - acc: 0.7570
    Epoch 42/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7288 - acc: 0.7589
    Epoch 43/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7290 - acc: 0.7557
    Epoch 44/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7259 - acc: 0.7572
    Epoch 45/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7255 - acc: 0.7579
    Epoch 46/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7272 - acc: 0.7565
    Epoch 47/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7285 - acc: 0.7575
    Epoch 48/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7253 - acc: 0.7582
    Epoch 49/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7286 - acc: 0.7570
    Epoch 50/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7257 - acc: 0.7560
    Epoch 51/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7254 - acc: 0.7586
    Epoch 52/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7242 - acc: 0.7580
    Epoch 53/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7244 - acc: 0.7568
    Epoch 54/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7248 - acc: 0.7563
    Epoch 55/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7230 - acc: 0.7580
    Epoch 56/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7278 - acc: 0.7570
    Epoch 57/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7206 - acc: 0.7587
    Epoch 58/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7242 - acc: 0.7565
    Epoch 59/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7247 - acc: 0.7584
    Epoch 60/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7221 - acc: 0.7598
    Epoch 61/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7263 - acc: 0.7592
    Epoch 62/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7234 - acc: 0.7570
    Epoch 63/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7211 - acc: 0.7592
    Epoch 64/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7248 - acc: 0.7577
    Epoch 65/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7213 - acc: 0.7591
    Epoch 66/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7202 - acc: 0.7600
    Epoch 67/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7213 - acc: 0.7583
    Epoch 68/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7196 - acc: 0.7600
    Epoch 69/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7226 - acc: 0.7573
    Epoch 70/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7185 - acc: 0.7584
    Epoch 71/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7211 - acc: 0.7578
    Epoch 72/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7203 - acc: 0.7589
    Epoch 73/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7191 - acc: 0.7576
    Epoch 74/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7206 - acc: 0.7583
    Epoch 75/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7204 - acc: 0.7586
    Epoch 76/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7187 - acc: 0.7590
    Epoch 77/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7212 - acc: 0.7594
    Epoch 78/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7178 - acc: 0.7595
    Epoch 79/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7167 - acc: 0.7603
    Epoch 80/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7189 - acc: 0.7591
    Epoch 81/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7167 - acc: 0.7610
    Epoch 82/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7192 - acc: 0.7598
    Epoch 83/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7191 - acc: 0.7587
    Epoch 84/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7164 - acc: 0.7603
    Epoch 85/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7167 - acc: 0.7609
    Epoch 86/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7180 - acc: 0.7585
    Epoch 87/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7160 - acc: 0.7600
    Epoch 88/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7191 - acc: 0.7591
    Epoch 89/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7168 - acc: 0.7604
    Epoch 90/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7158 - acc: 0.7598
    Epoch 91/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7140 - acc: 0.7612
    Epoch 92/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7164 - acc: 0.7605
    Epoch 93/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7153 - acc: 0.7601
    Epoch 94/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7154 - acc: 0.7591
    Epoch 95/200
    15788/15788 [==============================] - ETA: 0s - loss: 0.7152 - acc: 0.761 - 0s 20us/step - loss: 0.7165 - acc: 0.7609
    Epoch 96/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7146 - acc: 0.7594
    Epoch 97/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7139 - acc: 0.7606
    Epoch 98/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7154 - acc: 0.7600
    Epoch 99/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7144 - acc: 0.7610
    Epoch 100/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7148 - acc: 0.7605
    Epoch 101/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7143 - acc: 0.7589
    Epoch 102/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7133 - acc: 0.7596
    Epoch 103/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7134 - acc: 0.7599
    Epoch 104/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7131 - acc: 0.7613
    Epoch 105/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7111 - acc: 0.7599
    Epoch 106/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7159 - acc: 0.7599
    Epoch 107/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7108 - acc: 0.7605
    Epoch 108/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7166 - acc: 0.7606
    Epoch 109/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7155 - acc: 0.7582
    Epoch 110/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7106 - acc: 0.7611
    Epoch 111/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7148 - acc: 0.7587
    Epoch 112/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7104 - acc: 0.7601
    Epoch 113/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7104 - acc: 0.7600
    Epoch 114/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7130 - acc: 0.7610
    Epoch 115/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7127 - acc: 0.7612
    Epoch 116/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7127 - acc: 0.7601
    Epoch 117/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7109 - acc: 0.7600
    Epoch 118/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7108 - acc: 0.7603
    Epoch 119/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7116 - acc: 0.7615
    Epoch 120/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7091 - acc: 0.7613
    Epoch 121/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7063 - acc: 0.7613
    Epoch 122/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7101 - acc: 0.7610
    Epoch 123/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7102 - acc: 0.7601
    Epoch 124/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7082 - acc: 0.7628
    Epoch 125/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7099 - acc: 0.7611
    Epoch 126/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7128 - acc: 0.7604
    Epoch 127/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7102 - acc: 0.7599
    Epoch 128/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7097 - acc: 0.7620
    Epoch 129/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7079 - acc: 0.7610
    Epoch 130/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7089 - acc: 0.7608
    Epoch 131/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7078 - acc: 0.7621
    Epoch 132/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7060 - acc: 0.7617
    Epoch 133/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7073 - acc: 0.7610
    Epoch 134/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7092 - acc: 0.7607
    Epoch 135/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7086 - acc: 0.7596
    Epoch 136/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7076 - acc: 0.7615
    Epoch 137/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7075 - acc: 0.7606
    Epoch 138/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7078 - acc: 0.7601
    Epoch 139/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7076 - acc: 0.7619
    Epoch 140/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7096 - acc: 0.7617
    Epoch 141/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7082 - acc: 0.7612
    Epoch 142/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7101 - acc: 0.7603
    Epoch 143/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7055 - acc: 0.7605
    Epoch 144/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7097 - acc: 0.7601
    Epoch 145/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7039 - acc: 0.7629
    Epoch 146/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7080 - acc: 0.7603
    Epoch 147/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7043 - acc: 0.7625
    Epoch 148/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7077 - acc: 0.7624
    Epoch 149/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7090 - acc: 0.7618
    Epoch 150/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7059 - acc: 0.7618
    Epoch 151/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7047 - acc: 0.7611
    Epoch 152/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7056 - acc: 0.7602
    Epoch 153/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7058 - acc: 0.7624
    Epoch 154/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7030 - acc: 0.7619
    Epoch 155/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7076 - acc: 0.7603
    Epoch 156/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7069 - acc: 0.7617
    Epoch 157/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7053 - acc: 0.7627
    Epoch 158/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7024 - acc: 0.7625
    Epoch 159/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7050 - acc: 0.7605
    Epoch 160/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7041 - acc: 0.7621
    Epoch 161/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7050 - acc: 0.7607
    Epoch 162/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7067 - acc: 0.7603
    Epoch 163/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7021 - acc: 0.7620
    Epoch 164/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7030 - acc: 0.7633
    Epoch 165/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7027 - acc: 0.7618
    Epoch 166/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7045 - acc: 0.7606
    Epoch 167/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7053 - acc: 0.7615
    Epoch 168/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7013 - acc: 0.7626
    Epoch 169/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7051 - acc: 0.7611
    Epoch 170/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7020 - acc: 0.7602
    Epoch 171/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7037 - acc: 0.7614
    Epoch 172/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7026 - acc: 0.7610
    Epoch 173/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7028 - acc: 0.7611
    Epoch 174/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7030 - acc: 0.7624
    Epoch 175/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7038 - acc: 0.7616
    Epoch 176/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7058 - acc: 0.7622
    Epoch 177/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7031 - acc: 0.7624
    Epoch 178/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7046 - acc: 0.7622
    Epoch 179/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7031 - acc: 0.7627
    Epoch 180/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7046 - acc: 0.7618
    Epoch 181/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7025 - acc: 0.7610
    Epoch 182/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7005 - acc: 0.7632
    Epoch 183/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7013 - acc: 0.7625
    Epoch 184/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7010 - acc: 0.7630
    Epoch 185/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7034 - acc: 0.7622
    Epoch 186/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7021 - acc: 0.7612
    Epoch 187/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7017 - acc: 0.7632
    Epoch 188/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6999 - acc: 0.7618
    Epoch 189/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7016 - acc: 0.7632
    Epoch 190/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6992 - acc: 0.7617
    Epoch 191/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7007 - acc: 0.7606
    Epoch 192/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7003 - acc: 0.7613
    Epoch 193/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7004 - acc: 0.7613
    Epoch 194/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6999 - acc: 0.7638
    Epoch 195/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7019 - acc: 0.7620
    Epoch 196/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6989 - acc: 0.7629
    Epoch 197/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7021 - acc: 0.7624
    Epoch 198/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6991 - acc: 0.7624
    Epoch 199/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7001 - acc: 0.7639
    Epoch 200/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6988 - acc: 0.7615
    The accuracy(categorical) is: 0.8867494299467951
    The mean squared error is: 34.76057765391437
    


![png](output_8_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 200, batch_size = 2048)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/200
    15788/15788 [==============================] - 1s 49us/step - loss: 0.6991 - acc: 0.7615
    Epoch 2/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6998 - acc: 0.7621
    Epoch 3/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7020 - acc: 0.7608
    Epoch 4/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6983 - acc: 0.7644
    Epoch 5/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6985 - acc: 0.7628
    Epoch 6/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6994 - acc: 0.7626: 0s - loss: 0.7006 - acc: 0.76
    Epoch 7/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.7008 - acc: 0.7624
    Epoch 8/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6979 - acc: 0.7637
    Epoch 9/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7019 - acc: 0.7618
    Epoch 10/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6995 - acc: 0.7628
    Epoch 11/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6961 - acc: 0.7639
    Epoch 12/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6987 - acc: 0.7634
    Epoch 13/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7001 - acc: 0.7640
    Epoch 14/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6974 - acc: 0.7640
    Epoch 15/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6995 - acc: 0.7615
    Epoch 16/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6982 - acc: 0.7620
    Epoch 17/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7014 - acc: 0.7620
    Epoch 18/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6971 - acc: 0.7614
    Epoch 19/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6984 - acc: 0.7643
    Epoch 20/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6974 - acc: 0.7624
    Epoch 21/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6992 - acc: 0.7633
    Epoch 22/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6972 - acc: 0.7629
    Epoch 23/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6972 - acc: 0.7625
    Epoch 24/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6946 - acc: 0.7632
    Epoch 25/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6996 - acc: 0.7631
    Epoch 26/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6978 - acc: 0.7637
    Epoch 27/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6985 - acc: 0.7645
    Epoch 28/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6996 - acc: 0.7625
    Epoch 29/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6982 - acc: 0.7623
    Epoch 30/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6974 - acc: 0.7638
    Epoch 31/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6961 - acc: 0.7626
    Epoch 32/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6974 - acc: 0.7623
    Epoch 33/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6977 - acc: 0.7620
    Epoch 34/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6943 - acc: 0.7639
    Epoch 35/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6955 - acc: 0.7625
    Epoch 36/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6972 - acc: 0.7627
    Epoch 37/200
    15788/15788 [==============================] - ETA: 0s - loss: 0.6973 - acc: 0.763 - 0s 20us/step - loss: 0.6961 - acc: 0.7633
    Epoch 38/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.7010 - acc: 0.7618
    Epoch 39/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6952 - acc: 0.7638
    Epoch 40/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6934 - acc: 0.7664
    Epoch 41/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6984 - acc: 0.7629
    Epoch 42/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6932 - acc: 0.7629
    Epoch 43/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6961 - acc: 0.7639
    Epoch 44/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6956 - acc: 0.7628
    Epoch 45/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6958 - acc: 0.7636
    Epoch 46/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6973 - acc: 0.7623
    Epoch 47/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6983 - acc: 0.7639
    Epoch 48/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6953 - acc: 0.7630
    Epoch 49/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6947 - acc: 0.7649
    Epoch 50/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6966 - acc: 0.7647
    Epoch 51/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6931 - acc: 0.7635
    Epoch 52/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6974 - acc: 0.7622
    Epoch 53/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6963 - acc: 0.7623
    Epoch 54/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6941 - acc: 0.7642
    Epoch 55/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6930 - acc: 0.7639
    Epoch 56/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6936 - acc: 0.7643
    Epoch 57/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6938 - acc: 0.7639
    Epoch 58/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6949 - acc: 0.7638
    Epoch 59/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6944 - acc: 0.7628
    Epoch 60/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6931 - acc: 0.7647
    Epoch 61/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6929 - acc: 0.7645
    Epoch 62/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6933 - acc: 0.7629
    Epoch 63/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6970 - acc: 0.7638
    Epoch 64/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6917 - acc: 0.7630
    Epoch 65/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6930 - acc: 0.7647
    Epoch 66/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6931 - acc: 0.7647
    Epoch 67/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6967 - acc: 0.7625
    Epoch 68/200
    15788/15788 [==============================] - 0s 28us/step - loss: 0.6929 - acc: 0.7635
    Epoch 69/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6928 - acc: 0.7641
    Epoch 70/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6909 - acc: 0.7640
    Epoch 71/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6972 - acc: 0.7639
    Epoch 72/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6937 - acc: 0.7653
    Epoch 73/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6944 - acc: 0.7634
    Epoch 74/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6898 - acc: 0.7663
    Epoch 75/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6932 - acc: 0.7653
    Epoch 76/200
    15788/15788 [==============================] - 0s 28us/step - loss: 0.6938 - acc: 0.7640
    Epoch 77/200
    15788/15788 [==============================] - 0s 24us/step - loss: 0.6912 - acc: 0.7646
    Epoch 78/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6932 - acc: 0.7654
    Epoch 79/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6921 - acc: 0.7637
    Epoch 80/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.6935 - acc: 0.7647
    Epoch 81/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6945 - acc: 0.7650
    Epoch 82/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.6960 - acc: 0.7644
    Epoch 83/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.6891 - acc: 0.7654
    Epoch 84/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6927 - acc: 0.7646
    Epoch 85/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.6907 - acc: 0.7635
    Epoch 86/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.6921 - acc: 0.7642
    Epoch 87/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6915 - acc: 0.7652
    Epoch 88/200
    15788/15788 [==============================] - 0s 22us/step - loss: 0.6925 - acc: 0.7653
    Epoch 89/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6919 - acc: 0.7671
    Epoch 90/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6917 - acc: 0.7636
    Epoch 91/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6902 - acc: 0.7645
    Epoch 92/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6920 - acc: 0.7650
    Epoch 93/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6913 - acc: 0.7659
    Epoch 94/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6919 - acc: 0.7637
    Epoch 95/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6892 - acc: 0.7654
    Epoch 96/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6908 - acc: 0.7646
    Epoch 97/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6925 - acc: 0.7644
    Epoch 98/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6894 - acc: 0.7660
    Epoch 99/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6905 - acc: 0.7668
    Epoch 100/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6942 - acc: 0.7652
    Epoch 101/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6905 - acc: 0.7662
    Epoch 102/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6903 - acc: 0.7649
    Epoch 103/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6909 - acc: 0.7639
    Epoch 104/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6895 - acc: 0.7652
    Epoch 105/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6897 - acc: 0.7647
    Epoch 106/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6888 - acc: 0.7645
    Epoch 107/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6896 - acc: 0.7645
    Epoch 108/200
    15788/15788 [==============================] - ETA: 0s - loss: 0.6959 - acc: 0.762 - 0s 20us/step - loss: 0.6908 - acc: 0.7638
    Epoch 109/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6924 - acc: 0.7631
    Epoch 110/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6890 - acc: 0.7656
    Epoch 111/200
    15788/15788 [==============================] - ETA: 0s - loss: 0.6891 - acc: 0.765 - 0s 20us/step - loss: 0.6905 - acc: 0.7658
    Epoch 112/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6874 - acc: 0.7672
    Epoch 113/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6871 - acc: 0.7651
    Epoch 114/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6909 - acc: 0.7637
    Epoch 115/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6899 - acc: 0.7653
    Epoch 116/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6899 - acc: 0.7651
    Epoch 117/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6909 - acc: 0.7639
    Epoch 118/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6871 - acc: 0.7677
    Epoch 119/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6900 - acc: 0.7642
    Epoch 120/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6876 - acc: 0.7649
    Epoch 121/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6893 - acc: 0.7636
    Epoch 122/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6879 - acc: 0.7651
    Epoch 123/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6902 - acc: 0.7640
    Epoch 124/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6929 - acc: 0.7652
    Epoch 125/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6909 - acc: 0.7643
    Epoch 126/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6891 - acc: 0.7651
    Epoch 127/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6910 - acc: 0.7643
    Epoch 128/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6892 - acc: 0.7646
    Epoch 129/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6865 - acc: 0.7654
    Epoch 130/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6879 - acc: 0.7656
    Epoch 131/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6877 - acc: 0.7653
    Epoch 132/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6876 - acc: 0.7641
    Epoch 133/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6875 - acc: 0.7654
    Epoch 134/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6887 - acc: 0.7653
    Epoch 135/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6879 - acc: 0.7656
    Epoch 136/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6899 - acc: 0.7643
    Epoch 137/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6898 - acc: 0.7640
    Epoch 138/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6866 - acc: 0.7650
    Epoch 139/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6880 - acc: 0.7649
    Epoch 140/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6879 - acc: 0.7665
    Epoch 141/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6871 - acc: 0.7650
    Epoch 142/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6871 - acc: 0.7658
    Epoch 143/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6849 - acc: 0.7655
    Epoch 144/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6879 - acc: 0.7667
    Epoch 145/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6859 - acc: 0.7664
    Epoch 146/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6868 - acc: 0.7667
    Epoch 147/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6872 - acc: 0.7662
    Epoch 148/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6877 - acc: 0.7665
    Epoch 149/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6841 - acc: 0.7678
    Epoch 150/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6852 - acc: 0.7658
    Epoch 151/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6885 - acc: 0.7647
    Epoch 152/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6854 - acc: 0.7656
    Epoch 153/200
    15788/15788 [==============================] - 0s 24us/step - loss: 0.6869 - acc: 0.7663
    Epoch 154/200
    15788/15788 [==============================] - 0s 24us/step - loss: 0.6831 - acc: 0.7676
    Epoch 155/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6878 - acc: 0.7653
    Epoch 156/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6885 - acc: 0.7656
    Epoch 157/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6848 - acc: 0.7655
    Epoch 158/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6840 - acc: 0.7662
    Epoch 159/200
    15788/15788 [==============================] - 0s 28us/step - loss: 0.6870 - acc: 0.7657
    Epoch 160/200
    15788/15788 [==============================] - 0s 25us/step - loss: 0.6847 - acc: 0.7665
    Epoch 161/200
    15788/15788 [==============================] - 0s 26us/step - loss: 0.6867 - acc: 0.7660
    Epoch 162/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6879 - acc: 0.7657
    Epoch 163/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6868 - acc: 0.7663
    Epoch 164/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6821 - acc: 0.7677
    Epoch 165/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6840 - acc: 0.7654
    Epoch 166/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6868 - acc: 0.7662
    Epoch 167/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6825 - acc: 0.7659
    Epoch 168/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6874 - acc: 0.7635
    Epoch 169/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6832 - acc: 0.7675
    Epoch 170/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6846 - acc: 0.7674
    Epoch 171/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6837 - acc: 0.7669
    Epoch 172/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6869 - acc: 0.7652
    Epoch 173/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6844 - acc: 0.7667
    Epoch 174/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6866 - acc: 0.7670
    Epoch 175/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6850 - acc: 0.7667
    Epoch 176/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6848 - acc: 0.7647
    Epoch 177/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6857 - acc: 0.7651
    Epoch 178/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6853 - acc: 0.7634
    Epoch 179/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6846 - acc: 0.7656
    Epoch 180/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6846 - acc: 0.7660
    Epoch 181/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6841 - acc: 0.7656
    Epoch 182/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6837 - acc: 0.7668
    Epoch 183/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6825 - acc: 0.7660
    Epoch 184/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6810 - acc: 0.7646
    Epoch 185/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6836 - acc: 0.7663
    Epoch 186/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6845 - acc: 0.7668
    Epoch 187/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6849 - acc: 0.7665
    Epoch 188/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6842 - acc: 0.7653
    Epoch 189/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6829 - acc: 0.7663
    Epoch 190/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6827 - acc: 0.7663
    Epoch 191/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6849 - acc: 0.7674
    Epoch 192/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6828 - acc: 0.7643
    Epoch 193/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6848 - acc: 0.7663
    Epoch 194/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6831 - acc: 0.7655
    Epoch 195/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6787 - acc: 0.7667
    Epoch 196/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6820 - acc: 0.7656
    Epoch 197/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6810 - acc: 0.7670
    Epoch 198/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6844 - acc: 0.7669
    Epoch 199/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6819 - acc: 0.7665
    Epoch 200/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6814 - acc: 0.7674
    The accuracy(categorical) is: 0.8908031416265518
    The mean squared error is: 33.139092982011654
    


![png](output_9_1.png)



```python
# all the following code will be executed manually for every iteration
layers.fit(X_train_scaled, Y_train_encoded, epochs = 200, batch_size = 2048)

# layers.save('layers2_1.h5')  # creates a HDF5 file 'my_model.h5'
# layers = load_model('layers2_1.h5')

predicted_energy = layers.predict(X_test_scaled)
accuracy = sum(np.argmax(predicted_energy, axis = 1) == np.argmax(Y_test_encoded.values, axis = 1)) / len(Y_test_encoded.values)
print("The accuracy(categorical) is: {0}".format(accuracy))

predicted_energy_inversed = labelencoder_Y_1.inverse_transform(np.argmax(predicted_energy, axis = 1))
predicted_mse = mse(predicted_energy_inversed, Y[round(np.shape(Y)[0] * 0.8):])
print("The mean squared error is: {0}".format(predicted_mse))

plt.plot(Y[round(np.shape(Y)[0] * 0.8):], color = 'red', label = 'real energy')
plt.plot(predicted_energy_inversed, color = 'blue', label = 'Predicted energy')
plt.title('Appliances energy prediction')
plt.xlabel('Time')
plt.ylabel('energy')
plt.legend()
plt.show()
```

    Epoch 1/200
    15788/15788 [==============================] - 1s 49us/step - loss: 0.6827 - acc: 0.7670
    Epoch 2/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6830 - acc: 0.7653
    Epoch 3/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6819 - acc: 0.7666
    Epoch 4/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6816 - acc: 0.7651
    Epoch 5/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6812 - acc: 0.7653
    Epoch 6/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6805 - acc: 0.7677
    Epoch 7/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6832 - acc: 0.7658
    Epoch 8/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6817 - acc: 0.7673
    Epoch 9/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6801 - acc: 0.7667
    Epoch 10/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6812 - acc: 0.7670
    Epoch 11/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6810 - acc: 0.7657
    Epoch 12/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6829 - acc: 0.7660
    Epoch 13/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6796 - acc: 0.7671
    Epoch 14/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6818 - acc: 0.7677
    Epoch 15/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6816 - acc: 0.7653
    Epoch 16/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6779 - acc: 0.7683
    Epoch 17/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6819 - acc: 0.7682
    Epoch 18/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6800 - acc: 0.7654
    Epoch 19/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6802 - acc: 0.7667
    Epoch 20/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6811 - acc: 0.7670
    Epoch 21/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6790 - acc: 0.7662
    Epoch 22/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6780 - acc: 0.7679
    Epoch 23/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6781 - acc: 0.7675
    Epoch 24/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6811 - acc: 0.7675
    Epoch 25/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6793 - acc: 0.7670
    Epoch 26/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6813 - acc: 0.7663
    Epoch 27/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6787 - acc: 0.7639
    Epoch 28/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6786 - acc: 0.7659
    Epoch 29/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6814 - acc: 0.7665
    Epoch 30/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6795 - acc: 0.7672
    Epoch 31/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6812 - acc: 0.7654
    Epoch 32/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6811 - acc: 0.7677
    Epoch 33/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6773 - acc: 0.7688
    Epoch 34/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6807 - acc: 0.7677
    Epoch 35/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6795 - acc: 0.7663
    Epoch 36/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6833 - acc: 0.7665
    Epoch 37/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6791 - acc: 0.7664
    Epoch 38/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6800 - acc: 0.7675
    Epoch 39/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6793 - acc: 0.7655
    Epoch 40/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6786 - acc: 0.7669
    Epoch 41/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6811 - acc: 0.7637
    Epoch 42/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6785 - acc: 0.7662
    Epoch 43/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6772 - acc: 0.7675
    Epoch 44/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6781 - acc: 0.7674
    Epoch 45/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6781 - acc: 0.7670
    Epoch 46/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6799 - acc: 0.7652
    Epoch 47/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6793 - acc: 0.7662
    Epoch 48/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6795 - acc: 0.7668
    Epoch 49/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6796 - acc: 0.7668
    Epoch 50/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6751 - acc: 0.7690
    Epoch 51/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6786 - acc: 0.7649
    Epoch 52/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6752 - acc: 0.7676
    Epoch 53/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6774 - acc: 0.7680
    Epoch 54/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6760 - acc: 0.7663
    Epoch 55/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6799 - acc: 0.7683
    Epoch 56/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6745 - acc: 0.7668
    Epoch 57/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6748 - acc: 0.7667
    Epoch 58/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6774 - acc: 0.7689
    Epoch 59/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6798 - acc: 0.7658
    Epoch 60/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6777 - acc: 0.7669
    Epoch 61/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6758 - acc: 0.7673
    Epoch 62/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6791 - acc: 0.7660
    Epoch 63/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6765 - acc: 0.7685
    Epoch 64/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6746 - acc: 0.7674
    Epoch 65/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6763 - acc: 0.7679
    Epoch 66/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6780 - acc: 0.7673
    Epoch 67/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6794 - acc: 0.7668
    Epoch 68/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6738 - acc: 0.7675
    Epoch 69/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6799 - acc: 0.7674
    Epoch 70/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6748 - acc: 0.7683
    Epoch 71/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6758 - acc: 0.7666
    Epoch 72/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6761 - acc: 0.7679
    Epoch 73/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6779 - acc: 0.7686
    Epoch 74/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6739 - acc: 0.7696
    Epoch 75/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6755 - acc: 0.7694
    Epoch 76/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6747 - acc: 0.7701
    Epoch 77/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6779 - acc: 0.7670
    Epoch 78/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6736 - acc: 0.7688
    Epoch 79/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6752 - acc: 0.7681
    Epoch 80/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6775 - acc: 0.7668
    Epoch 81/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6750 - acc: 0.7688
    Epoch 82/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6745 - acc: 0.7679
    Epoch 83/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6740 - acc: 0.7680
    Epoch 84/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6757 - acc: 0.7684
    Epoch 85/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6793 - acc: 0.7670
    Epoch 86/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6733 - acc: 0.7686
    Epoch 87/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6754 - acc: 0.7661
    Epoch 88/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6772 - acc: 0.7686
    Epoch 89/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6726 - acc: 0.7677
    Epoch 90/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6755 - acc: 0.7663
    Epoch 91/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6709 - acc: 0.7690
    Epoch 92/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6744 - acc: 0.7691
    Epoch 93/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6722 - acc: 0.7684
    Epoch 94/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6742 - acc: 0.7675
    Epoch 95/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6761 - acc: 0.7672
    Epoch 96/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6733 - acc: 0.7683
    Epoch 97/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6724 - acc: 0.7679
    Epoch 98/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6725 - acc: 0.7685
    Epoch 99/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6705 - acc: 0.7685
    Epoch 100/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6713 - acc: 0.7693
    Epoch 101/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6735 - acc: 0.7664
    Epoch 102/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6728 - acc: 0.7696
    Epoch 103/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6712 - acc: 0.7670
    Epoch 104/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6734 - acc: 0.7695
    Epoch 105/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6763 - acc: 0.7691
    Epoch 106/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6718 - acc: 0.7670
    Epoch 107/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6733 - acc: 0.7677
    Epoch 108/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6757 - acc: 0.7680
    Epoch 109/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6741 - acc: 0.7648
    Epoch 110/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6699 - acc: 0.7672
    Epoch 111/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6727 - acc: 0.7675
    Epoch 112/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6743 - acc: 0.7686
    Epoch 113/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6694 - acc: 0.7697
    Epoch 114/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6733 - acc: 0.7674
    Epoch 115/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6707 - acc: 0.7685
    Epoch 116/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6724 - acc: 0.7685
    Epoch 117/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6754 - acc: 0.7675
    Epoch 118/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6708 - acc: 0.7679
    Epoch 119/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6729 - acc: 0.7684
    Epoch 120/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6719 - acc: 0.7698
    Epoch 121/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6705 - acc: 0.7684
    Epoch 122/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6699 - acc: 0.7696
    Epoch 123/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6722 - acc: 0.7681
    Epoch 124/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6740 - acc: 0.7674
    Epoch 125/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6683 - acc: 0.7684
    Epoch 126/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6742 - acc: 0.7663
    Epoch 127/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6685 - acc: 0.7703
    Epoch 128/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6692 - acc: 0.7696
    Epoch 129/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6710 - acc: 0.7681
    Epoch 130/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6675 - acc: 0.7675
    Epoch 131/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6716 - acc: 0.7677
    Epoch 132/200
    15788/15788 [==============================] - ETA: 0s - loss: 0.6691 - acc: 0.772 - 0s 20us/step - loss: 0.6717 - acc: 0.7712
    Epoch 133/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6708 - acc: 0.7665
    Epoch 134/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6715 - acc: 0.7697
    Epoch 135/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6679 - acc: 0.7684
    Epoch 136/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6712 - acc: 0.7689
    Epoch 137/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6706 - acc: 0.7689
    Epoch 138/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6698 - acc: 0.7680
    Epoch 139/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6705 - acc: 0.7696
    Epoch 140/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6701 - acc: 0.7694
    Epoch 141/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6715 - acc: 0.7672
    Epoch 142/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6685 - acc: 0.7684
    Epoch 143/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6697 - acc: 0.7672
    Epoch 144/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6706 - acc: 0.7691
    Epoch 145/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6705 - acc: 0.7694
    Epoch 146/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6719 - acc: 0.7672
    Epoch 147/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6706 - acc: 0.7689
    Epoch 148/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6677 - acc: 0.7682
    Epoch 149/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6692 - acc: 0.7696
    Epoch 150/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6650 - acc: 0.7707
    Epoch 151/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6739 - acc: 0.7684
    Epoch 152/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6679 - acc: 0.7699
    Epoch 153/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6682 - acc: 0.7698
    Epoch 154/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6670 - acc: 0.7682
    Epoch 155/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6702 - acc: 0.7672
    Epoch 156/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6653 - acc: 0.7684
    Epoch 157/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6689 - acc: 0.7689
    Epoch 158/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6655 - acc: 0.7695
    Epoch 159/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6666 - acc: 0.7705
    Epoch 160/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6664 - acc: 0.7704
    Epoch 161/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6686 - acc: 0.7694
    Epoch 162/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6684 - acc: 0.7693
    Epoch 163/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6664 - acc: 0.7689
    Epoch 164/200
    15788/15788 [==============================] - 0s 23us/step - loss: 0.6651 - acc: 0.7714
    Epoch 165/200
    15788/15788 [==============================] - 0s 24us/step - loss: 0.6683 - acc: 0.7679
    Epoch 166/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6688 - acc: 0.7681
    Epoch 167/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6659 - acc: 0.7705
    Epoch 168/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6701 - acc: 0.7693
    Epoch 169/200
    15788/15788 [==============================] - 0s 26us/step - loss: 0.6651 - acc: 0.7703
    Epoch 170/200
    15788/15788 [==============================] - 0s 27us/step - loss: 0.6688 - acc: 0.7700
    Epoch 171/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6680 - acc: 0.7692
    Epoch 172/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6699 - acc: 0.7693
    Epoch 173/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6671 - acc: 0.7703
    Epoch 174/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6630 - acc: 0.7699
    Epoch 175/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6667 - acc: 0.7689
    Epoch 176/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6626 - acc: 0.7700
    Epoch 177/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6679 - acc: 0.7700
    Epoch 178/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6703 - acc: 0.7693
    Epoch 179/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6678 - acc: 0.7679
    Epoch 180/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6644 - acc: 0.7696
    Epoch 181/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6654 - acc: 0.7703
    Epoch 182/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6642 - acc: 0.7712
    Epoch 183/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6634 - acc: 0.7713
    Epoch 184/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6643 - acc: 0.7709
    Epoch 185/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6645 - acc: 0.7671
    Epoch 186/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6644 - acc: 0.7705
    Epoch 187/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6655 - acc: 0.7700
    Epoch 188/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6651 - acc: 0.7701
    Epoch 189/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6677 - acc: 0.7683
    Epoch 190/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6667 - acc: 0.7686
    Epoch 191/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6642 - acc: 0.7716
    Epoch 192/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6629 - acc: 0.7699
    Epoch 193/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6631 - acc: 0.7691
    Epoch 194/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6634 - acc: 0.7720
    Epoch 195/200
    15788/15788 [==============================] - 0s 21us/step - loss: 0.6667 - acc: 0.7691
    Epoch 196/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6631 - acc: 0.7714
    Epoch 197/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6684 - acc: 0.7681
    Epoch 198/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6633 - acc: 0.7701
    Epoch 199/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6617 - acc: 0.7709
    Epoch 200/200
    15788/15788 [==============================] - 0s 20us/step - loss: 0.6631 - acc: 0.7696
    The accuracy(categorical) is: 0.8910564986065366
    The mean squared error is: 32.835064606029896
    


![png](output_10_1.png)


- We ran 4 iterations, and with “epochs=200”, “batch_size=2048” for each. In the last iteration, we found that that the accuracy of categorical prediction reaches 89%, almost 90%, but from the graph we can see that most of the red lines, which indicate the real energy, is not overlain by the blue lines, which indicate the predicted value. It seems the accuracies are not consistent with the graphs.
